
function getWordpressCOMPosts(urls, n) {
    return new Promise((resolve, reject) => {
        try {
            async.map(urls, async function (url) {
                url = `https://public-api.wordpress.com/rest/v1.2/sites/${url}/posts?http_envelope=1&number=${n}`;
                const response = await fetch(url)
                return response.json()
            }, (err, results) => {
                if (err) {
                    console.log(err);                  
                }
                else {                   
                    resolve(normalizeWordpressCOM(results));
                }

            })
        } catch (err) { reject(err) }
    })
}
function loading(){
    $("#content").html(``);
    $("#content").html(`<div class="d-flex justify-content-center text-center">
    <div class="spinner-border" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
  </div>`);
}
function randomIntFromInterval(min, max) { // min and max included 
    return Math.floor(Math.random() * (max - min + 1) + min)
}
var items = ["166419546","176892389","171782886","126020344","197693856","77118218","198147347","190074382","104427747","26599698",
            "150193535","130178575","129246078","124297619","150998827","176658602","70135762","16518427","156670177","59022636",
            "114793426","98926692","133888116","61723818","41974132","92754887","53484977","24557832","81185863",
            '81185863', '168924928', '128538468', '107287630', '26503181', '181208753', '202363771', '199479050', '83380856', '197082858', '186482930', '67193600', '83408982', '107802121', '123234112', '112748289', '81755486', '203757597', '207862771', '37419670',
            '168924928', '128538468', '107287630', '26503181', '181208753', '202363771', '199479050', '83380856', '197082858', '186482930', '67193600', '83408982', '107802121', '123234112', '112748289', '81755486', '203757597', '207862771', '37419670', '135776798',
            '140467884', '29747589', '18048500', '13906279', '205334752', '42179464', '120402697', '76238136', '82437990', '83086945', '11123767', '81185863', '46732184', '58539435', '92420470', '60992471', '148614258', '9340381', '26669070', '42146343',
            '29747589', '18048500', '13906279', '205334752', '42179464', '120402697', '76238136', '82437990', '83086945', '11123767', '81185863', '46732184', '58539435', '92420470', '60992471', '148614258', '9340381', '26669070', '42146343', '124666323',
            '155557216', '133592157', '14754275', '54397254', '4318514', '102259419', '33744645', '130369440', '136556798', '108070303', '13642420', '160775310', '844237', '159351346', '32870451', '123308545', '106482264', '168751021', '122601703', '129677600',
            '4315286', '155557216', '133592157', '14754275', '54397254', '4318514', '102259419', '33744645', '130369440', '136556798', '108070303', '13642420', '160775310', '844237', '159351346', '32870451', '123308545', '106482264', '168751021', '122601703',
            '55684572', '133617928', '85701231', '13541176', '4413282', '66029000', '17509767', '164753072', '17958378', '136451602', '198646494', '142026233', '179735188', '67468903', '142028711', '77163035', '141362749', '12934457', '141366596', '59022636',
            '133617928', '85701231', '13541176', '4413282', '66029000', '17509767', '164753072', '17958378', '136451602', '198646494', '142026233', '179735188', '67468903', '142028711', '77163035', '141362749', '12934457', '141366596', '59022636', '101842704',
            '137436347', '178364305', '59275958', '201974990', '196523531', '120050470', '206890644', '193601055', '208764136', '173305711', '76185562', '108102734', '29500327', '118693224', '207960366', '13175970', '177305884', '72085838', '24104337', '117861268',
            '106156040', '137436347', '178364305', '59275958', '201974990', '196523531', '120050470', '206890644', '193601055', '208764136', '173305711', '76185562', '108102734', '29500327', '118693224', '207960366', '13175970', '177305884', '72085838', '24104337']

getURL(true);
$(".mybutton").on("click",function(e){
    getURL(true);   
})

function getURL(israndom){
    loading();
    if(israndom){
        console.log("random")
        fetch(`https://public-api.wordpress.com/rest/v1.2/sites/${randomIntFromInterval(10000,200000000)}/posts?http_envelope=1&number=1`)
        .then((response) => response.json())
        .then((data) => {
            console.log(data);
            if(data){
                if(data.body){
                    if(data.body.posts){
                        if(data.body.posts.length >= 1){
                            if(data.body.posts[0]){
                                v = data.body.posts[0]
                                var {hostname} =new URL(v.URL)
                                let sitename = v.site_name ? v.site_name : hostname
                                $("#content").html(`<img src="https://icon.horse/icon/${hostname.replace("www.", "")}" alt="" height="16" width="16" style="object-fit:cover"> <span class="small">${sitename}</span>`)
                                $("#content").append(`<h1 class="mt-2">${v.title}</h1>`)
                                $("#content").append(`<p class="mt-2">${v.author.name} | ${v.date}</p>`)                                                     
                                $("#content").append(`<hr>`)
                                $("#content").append(`${v.content}`)
                            }else{
                                getURL(true);
                            }
                        }else{
                            getURL(true);
                        }
                    }else{
                        getURL(true);
                    }
                }
                else{
                    getURL(true);
                }
            }
            else{
                getURL(true);
            }            
        });

    }else{
        console.log("selected")
        fetch(`https://public-api.wordpress.com/rest/v1.2/sites/${items[Math.floor(Math.random() * items.length)]}/posts?http_envelope=1&number=1&order=desc&after=2022-01-01`)
        .then((response) => response.json())
        .then((data) => {
            console.log(data);
            if(data){
                if(data.body){
                    if(data.body.posts){
                        if(data.body.posts.length >= 1){
                            if(data.body.posts[0]){
                                v = data.body.posts[0]
                                var {hostname} =new URL(v.URL)
                                $("#content").html(`<img src="https://icon.horse/icon/${hostname.replace("www.", "")}" alt="" height="16" width="16" style="object-fit:cover"> <span class="small">${hostname}</span>`)
                                $("#content").append(`<h1 class="mt-2">${v.title}</h1>`)
                                $("#content").append(`<p class="mt-2">${v.author.name} | ${v.date}</p>`)                                                     
                                $("#content").append(`<hr>`)
                                $("#content").append(`${v.content}`)
                            }else{
                                getURL();
                            }
                        }else{
                            getURL();
                        }
                    }else{
                        getURL();
                    }
                }
                else{
                    getURL();
                }
            }
            else{
                getURL();
            }            
        });
    }
   
}

function getIDsbySearch(searchTerm){
    fetch(`https://public-api.wordpress.com/rest/v1.1/read/feed?http_envelope=1&q=${searchTerm}&offset=0&exclude_followed=false&sort=relevance&locale=en-in&number=20`)
    .then((response) => response.json())
    .then((data) => {
        var arr=[];
        console.log(data);
        $.each(data.body.feeds, function(k,v){
            arr.push(v.blog_ID)
        })
       console.log(arr);
       return arr;
    })
}

function getPostsByTag(tag){
    loading();
    fetch(`https://public-api.wordpress.com/rest/v1/read/tags/${tag}/posts/?number=40&http_envelope=1&order=desc`)
    .then((response) => response.json())
    .then((data) => {       
        console.log(data);
        v = data.body.posts[randomIntFromInterval(0,data.body.posts.length-1)]        
        var {hostname} =new URL(v.URL);      
        $("#content").html(`<img src="https://icon.horse/icon/${hostname.replace("www.", "")}" alt="" height="16" width="16" style="object-fit:cover"> <span class="small">${hostname}</span>`);
        $("#content").append(`<h1 class="mt-2">${v.title}</h1>`)
        $("#content").append(`<p class="mt-2">${v.author.name} | ${v.date}</p>`)                                                     
        $("#content").append(`<hr>`)
        $("#content").append(`${v.content}`)
    })
}

$("#searchButton").on("click", function(e){
    e.preventDefault();
    var searchTerm =  $("#searchText").val();
    loading();
    fetch(`https://public-api.wordpress.com/rest/v1.2/read/search?http_envelope=1&sort=relevance&q=${searchTerm}&number=20&locale=en-gb`)
    .then((response) => response.json())
    .then((data) => {
        v = data.body.posts[randomIntFromInterval(0,data.body.posts.length-1)] 
        console.log(v);
        var {hostname} =new URL(v.URL); 
        let authorname = v.author ? v.author.name : ``     
        $("#content").html(`<img src="https://icon.horse/icon/${hostname.replace("www.", "")}" alt="" height="16" width="16" style="object-fit:cover"> <span class="small">${hostname}</span>`);
        $("#content").append(`<h1 class="mt-2">${v.title}</h1>`)
        $("#content").append(`<p class="mt-2">${authorname} | ${v.date}</p>`)                                                     
        $("#content").append(`<hr>`)
        $("#content").append(`${v.content}`)
    })
})
$(".verified").on("click", function(e){
    e.preventDefault();
   getURL(false);
})

function updateDOM(v){
    var {hostname} =new URL(v.URL)
    $("#content").html(`<img src="https://icon.horse/icon/${hostname.replace("www.", "")}" alt="" height="16" width="16" style="object-fit:cover"> <span class="small">${hostname}</span>`)
    $("#content").append(`<h1 class="mt-2">${v.title}</h1>`)
    $("#content").append(`<p class="mt-2">${v.author.name} | ${v.date}</p>`)                                                     
    $("#content").append(`<hr>`)
    $("#content").append(`${v.content}`)
}
GetTrendingTags();
function GetTrendingTags(){
    // $("#trendingtags").html(``);
    fetch(`https://public-api.wordpress.com/rest/v1.2/read/trending/tags`)
    .then((response) => response.json())
    .then((data) => {        
        $.each(data.tags, function(k,v){
            var $listItem  = $(`
            <button type="button" class="btn btn-primary btn-sm ${v.tag.slug} m-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-shuffle" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M0 3.5A.5.5 0 0 1 .5 3H1c2.202 0 3.827 1.24 4.874 2.418.49.552.865 1.102 1.126 1.532.26-.43.636-.98 1.126-1.532C9.173 4.24 10.798 3 13 3v1c-1.798 0-3.173 1.01-4.126 2.082A9.624 9.624 0 0 0 7.556 8a9.624 9.624 0 0 0 1.317 1.918C9.828 10.99 11.204 12 13 12v1c-2.202 0-3.827-1.24-4.874-2.418A10.595 10.595 0 0 1 7 9.05c-.26.43-.636.98-1.126 1.532C4.827 11.76 3.202 13 1 13H.5a.5.5 0 0 1 0-1H1c1.798 0 3.173-1.01 4.126-2.082A9.624 9.624 0 0 0 6.444 8a9.624 9.624 0 0 0-1.317-1.918C4.172 5.01 2.796 4 1 4H.5a.5.5 0 0 1-.5-.5z"/>
                    <path d="M13 5.466V1.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384l-2.36 1.966a.25.25 0 0 1-.41-.192zm0 9v-3.932a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384l-2.36 1.966a.25.25 0 0 1-.41-.192z"/>
                </svg>
                ${v.tag.title}
            </button>
            `);
            $listItem.on("click", function (e) {
                getPostsByTag(v.tag.slug)
            });
            $("#trendingtags").append($listItem);
        })
    })
}


const myOffcanvas = document.getElementById('offcanvasRight')
myOffcanvas.addEventListener('shown.bs.offcanvas', event => {
    $("#contentcontainer").attr("style","margin: auto; padding-left:200px")
})
myOffcanvas.addEventListener('hidden.bs.offcanvas', event => {
    $("#contentcontainer").attr("style","margin: auto;")
})




