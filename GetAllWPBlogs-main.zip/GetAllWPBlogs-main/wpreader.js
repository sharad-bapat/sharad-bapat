const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const from = urlParams.get('from');
const to = urlParams.get('to');
console.log(from, to)


for (i = Number(from); i < Number(to); i++) {
    fetchURL(`https://public-api.wordpress.com/rest/v1.2/sites/${i}?http_envelope=1`, i);
}

async function fetchURL(url, i) {    
    const response = await fetch(url);
    const data = await response.json();
    populatee(data)    
}
function populatee(data) {
    item = data.body;
    if (data.code == 200) {
        if (item.URL != "") {
            var $listItem = $(`               
                        <tr>
                            <td>${item.ID}</td>
                            <td>${item.Name}</td>                            
                            <td>${item.Description}</td>
                            <td>${item.URL}</td>
                            <td>${item.subscribers_count}</td>                            
                        </tr>                                               
        `);
            $("#homePage").append($listItem);
            window.scrollTo(0, document.body.scrollHeight);
        }

    }
}

function copyTable(el) {
    var table = document.getElementById(el);   
    if (navigator.clipboard) {
        var text = table.innerText.trim();
        navigator.clipboard.writeText(text).catch(function () { });
    }
}



