<?php
require_once('MoebooruBridge.php');

class YandereBridge extends MoebooruBridge {

	const MAINTAINER = 'mitsukarenai';
	const NAME = 'Yande.re';
	const URI = 'https://yande.re/';
	const DESCRIPTION = 'Returns images from given page and tags';

}
