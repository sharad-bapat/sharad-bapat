<?php
require_once('Shimmie2Bridge.php');

class MilbooruBridge extends Shimmie2Bridge {

	const MAINTAINER = 'mitsukarenai';
	const NAME = 'Milbooru';
	const URI = 'http://sheslostcontrol.net/moe/shimmie/';
	const DESCRIPTION = 'Returns images from given page';

}
