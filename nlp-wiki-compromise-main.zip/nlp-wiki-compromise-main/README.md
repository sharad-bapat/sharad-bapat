# nlp-wiki-compromise
Natural Language Processing on English Wikipedia articles with compromise Library

A browser based application for analyzing English Wikipedia pages with [compromise library](https://github.com/spencermountain/compromise/).
Download the index.html and nlp.min.js and use locally.
