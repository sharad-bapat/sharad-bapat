alert('Hello, world!');
document.body.innerHTML  ="";