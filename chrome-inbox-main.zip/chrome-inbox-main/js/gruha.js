function timeSince(date) {
    var seconds = Math.floor((new Date() - date) / 1000);  
    var interval = Math.floor(seconds / 31536000);

    if (interval > 1) {
      return interval + " years ago";
    }
    interval = Math.floor(seconds / 2592000);
    if (interval > 1) {
      return interval + " months ago";
    }
    interval = Math.floor(seconds / 86400);
    if (interval > 1) {
      return interval + " days ago";
    }
    interval = Math.floor(seconds / 3600);
    if (interval > 1) {
      return interval + " hours ago";
    }
    interval = Math.floor(seconds / 60);
    if (interval > 1) {
      return interval + " minutes ago";
    }
    return Math.floor(seconds) + " seconds ago";

}

$(function () {
    subreddit_autocomplete();
    update_gdelt_autocomplete();
    // getReddit("worldnews+technology+business+finance+news+technews+economy+news+entertainment")
    // .then(data=>{
    //     populate(data);
    //     $("#article_details").css("display:none");
    //     $("#article_list").css("display:block");
    // })
    // getSingleRSS('https://emm.newsbrief.eu/rss/rss?type=category&id=Conflict&language=en&duplicates=false').then(data=>populate(data));
    
    
});

$(".r_news").on("click", function(e){
    getReddit("worldnews+technology+business+finance+news+technews+economy+news+entertainment")
    .then(data=>{
        populate(data);
        $(".r_news").css(`backgroundColor: '#d2f4ea'`);
        $("#article_details").css("display:none");
        $("#article_list").css("display:block");
    })
   
})

$("#a_emm_top").on("click", function(e){
    getEMM("top")
    .then(data=>{
        $("#a_emm_top").css(`backgroundColor: '#d2f4ea'`);
        $("#article_details").css("display:none");
        $("#article_list").css("display:block");
        populate(data);
    })
   
});
$("#a_emm_events").on("click", function(e){
    getEMM("events")
    .then(data=>{
        $("#a_emm_events").css(`backgroundColor: '#d2f4ea'`);
        $("#article_details").css("display:none");
        $("#article_list").css("display:block");
        populate(data);
    })   
});

$("#a_emm_india").on("click", function(e){
    getEMMbyCategory("India")
    .then(data=>{
        $("#a_emm_india").css(`backgroundColor: '#d2f4ea'`);
        $("#article_details").css("display:none");
        $("#article_list").css("display:block");
        populate(data);
    })   
});

$("#a_emm_uk").on("click", function(e){
    getEMMbyCategory("UnitedKingdom")
    .then(data=>{
        $("#a_emm_uk").css(`backgroundColor: '#d2f4ea'`);
        $("#article_details").css("display:none");
        $("#article_list").css("display:block");
        populate(data);
    })   
});

$("#a_gdelt_india_english").on("click", function(e){
    getGDELT('sourcelang:eng%20sourcecountry:india',250,'6h','datedesc')
    .then(data=>{
        $("#a_gdelt_india_english").css(`backgroundColor: '#d2f4ea'`);
        $("#article_details").css("display:none");
        $("#article_list").css("display:block");
        populate(data);
    })   
});

$("#a_gdelt_hindi").on("click", function(e){
    getGDELT('sourcelang:hindi',250,'6h','datedesc')
    .then(data=>{
        $("#a_gdelt_hindi").css(`backgroundColor: '#d2f4ea'`);
        $("#article_details").css("display:none");
        $("#article_list").css("display:block");
        populate(data);
    })   
});

$("#a_gdelt_marathi").on("click", function(e){
    getGDELT('sourcelang:marathi',250,'6h','datedesc')
    .then(data=>{
        $("#a_gdelt_marathi").css(`backgroundColor: '#d2f4ea'`);
        $("#article_details").css("display:none");
        $("#article_list").css("display:block");
        populate(data);
    })   
});

$("#rss_world_news").on("click", function (e){
    getMultipleRSS([
        'https://feeds.npr.org/1001/rss.xml',
        'http://feeds.bbci.co.uk/news/world/rss.xml',
        'http://rss.cnn.com/rss/edition_world.rss',
        'https://rss.nytimes.com/services/xml/rss/nyt/World.xml',
        'http://www.aljazeera.com/xml/rss/all.xml',
        'https://timesofindia.indiatimes.com/rssfeeds/296589292.cms',
        'https://www.cnbc.com/id/100727362/device/rss/rss.html',        
    ]).then(data=>populate(data));
})

$("#rss_tech_news").on("click", function (e){
    getMultipleRSS([
        'https://www.techmeme.com/feed.xml?x=1',
        'https://www.wired.com/feed/rss',
        'https://techcrunch.com/feed/',
        'https://www.technologyreview.com/topnews.rss',
        'http://www.theverge.com/rss/frontpage',
        'http://feeds.feedburner.com/venturebeat/SZYF',
        'http://feeds.arstechnica.com/arstechnica/technology-lab',     
    ]).then(data=>populate(data));
})
$("#rss_india_news").on("click", function (e){
    getMultipleRSS([
        'http://feeds.feedburner.com/NDTV-LatestNews',
        'https://www.indiatoday.in/rss/1206578',
        'https://indianexpress.com/feed/',
        'https://www.thehindu.com/news/national/?service=rss',
        'http://www.news18.com/rss/india.xml',
        'https://www.dnaindia.com/feeds/india.xml',
        'https://www.deccanchronicle.com/rss_feed/',
        'http://feeds.feedburner.com/ScrollinArticles.rss',
        'https://prod-qt-images.s3.amazonaws.com/production/thequint/feed.xml',
        'https://telanganatoday.com/feed',
        'https://cms.qz.com/feed/edition/india/',      
    ]).then(data=>populate(data));
})

$("#rss_business_news").on("click", function (e){
    getMultipleRSS([
        'https://economictimes.indiatimes.com/rssfeedsdefault.cms',
        'http://www.financialexpress.com/feed',
        'https://prod-qt-images.s3.amazonaws.com/production/bloombergquint/feed.xml',        
        'https://www.ft.com/?format=rss',    
    ]).then(data=>populate(data));
})


//GDELT
function normalizeGDELT(results){
    console.log(results);
    arr = []    
    for (index in results) {
        if (results[index].articles) {
            results[index].articles.forEach(item => {
                var item_index = arr.findIndex(x => x.link == item.url);
                if (item_index === -1) {
                    var mDate = item.seendate.slice(0, 4) + "-" + item.seendate.slice(4, 6) + "-" + item.seendate.slice(6, 8)
                        + " " + item.seendate.slice(9, 11) + ":" + item.seendate.slice(11, 13)
                        + ":" + item.seendate.slice(13, 15);
                    //var unixtime = Date.parse(mDate);
                    var {hostname} = new URL(item.url);
                    let media = item.socialimage ?  item.socialimage : ``;                    
                    let iDate = mDate ? `${timeSince(new Date(mDate))}` : ``
                    let published =  Date.parse(mDate);
                    let title =  item.title ? item.title.replaceAll(" - ", "-").replaceAll(" %", "%").replaceAll(" .", ".") : ``
                    let content =  item.content ? item.content : ``
                    arr.push({
                        "title": title,
                        "link": item.url,
                        "content": content,
                        "iDate": iDate,
                        "media": media,
                        "published":published,
                    })                   
                }
            });
        }
    }
    arrr = arr.sort(function (a, b) {
        return b.created - a.created;
    });   
    return arrr
}
function getGDELT(query,maxrecords,timespan,sort) {
    return new Promise((resolve, reject) => {
        try {
            console.log(`https://api.gdeltproject.org/api/v2/doc/doc?query=${query}&mode=artlist&sort=${sort}&format=json&maxrecords=${maxrecords}&&timespan=${timespan}`);
            urls = [`https://api.gdeltproject.org/api/v2/doc/doc?query=${query}&mode=artlist&sort=${sort}&format=json&maxrecords=${maxrecords}&&timespan=${timespan}`]
            async.map(urls, async function (url) {
                try {
                    const response = await fetch(url);
                    return response.json()
                } catch (err) {
                    return {}
                }
            }, (err, results) => {
                console.log(results);
                response = normalizeGDELT(results);
                resolve(response)
            })
        } catch (err) { reject(err) }
    })
}
function update_gdelt_autocomplete() {
    var themetags = ["AFFECT", "AGRICULTURE", "ALLIANCE", "APPOINTMENT", "ARMEDCONFLICT", "ARREST", "ASSASSINATION", "AUSTERITY", "BAN", "BLOCKADE", "BORDER", "BULLYING", "CEASEFIRE", "CHECKPOINT", "CLOSURE", "CONFISCATION", "CONSTITUTIONAL", "CORRUPTION", "CURFEW", "DEFECTION", "DELAY", "DEMOCRACY", "DISABILITY", "DISCRIMINATION", "DISPLACED", "DRONES", "EDUCATION", "ELECTION", "EVACUATION", "EXHUMATION", "EXILE", "EXTREMISM", "FREESPEECH", "FUELPRICES", "GENTRIFICATION", "GRIEVANCES", "HARASSMENT", "IDEOLOGY", "IMMIGRATION", "IMPEACHMENT", "INEQUALITY", "INSURGENCY", "JIHAD", "JUSTICE", "KIDNAP", "KILL", "LANDMINE", "LEADER", "LEGALIZE", "LEGISLATION", "LGBT", "LITERACY", "LOCUSTS", "MARITIME", "MEDICAL", "MILITARY", "NEGOTIATIONS", "PEACEKEEPING", "PERSECUTION", "PIRACY", "POVERTY", "PRIVATIZATION", "PROPAGANDA", "PROTEST", "RAPE", "RATIFY", "REBELLION", "REBELS", "RECRUITMENT", "REFUGEES", "RELATIONS", "RELIGION", "RESIGNATION", "RETALIATE", "RETIREMENT", "RETIREMENTS", "RURAL", "SANCTIONS", "SANITATION", "SCANDAL", "SCIENCE", "SEIGE", "SEIZE", "SEPARATISTS", "SHORTAGE", "SICKENED", "SLUMS", "SMUGGLING", "SOVEREIGNTY", "STRIKE", "SURVEILLANCE", "TERROR", "TORTURE", "TOURISM", "TRAFFIC", "TRANSPARENCY", "TREASON", "TRIAL", "UNEMPLOYMENT", "UNGOVERNED", "URBAN", "VANDALIZE", "VETO", "WHISTLEBLOWER", "WMD", "WOUND"];
    var countrytags = ["Andorra", "United Arab Emirates", "Afghanistan", "Antigua and Barbuda", "Anguilla", "Albania", "Armenia", "Angola", "Antarctica", "Argentina", "American Samoa", "Austria", "Australia", "Aruba", "�land", "Azerbaijan", "Bosnia and Herzegovina", "Barbados", "Bangladesh", "Belgium", "Burkina Faso", "Bulgaria", "Bahrain", "Burundi", "Benin", "Saint Barth�lemy", "Bermuda", "Brunei", "Bolivia", "Bonaire", "Brazil", "Bahamas", "Bhutan", "Bouvet Island", "Botswana", "Belarus", "Belize", "Canada", "Cocos [Keeling] Islands", "Congo", "Central African Republic", "Republic of the Congo", "Switzerland", "Ivory Coast", "Cook Islands", "Chile", "Cameroon", "China", "Colombia", "Costa Rica", "Cuba", "Cape Verde", "Curacao", "Christmas Island", "Cyprus", "Czechia", "Germany", "Djibouti", "Denmark", "Dominica", "Dominican Republic", "Algeria", "Ecuador", "Estonia", "Egypt", "Western Sahara", "Eritrea", "Spain", "Ethiopia", "Finland", "Fiji", "Falkland Islands", "Micronesia", "Faroe Islands", "France", "Gabon", "United Kingdom", "Grenada", "Georgia", "French Guiana", "Guernsey", "Ghana", "Gibraltar", "Greenland", "Gambia", "Guinea", "Guadeloupe", "Equatorial Guinea", "Greece", "South Georgia and the South Sandwich Islands", "Guatemala", "Guam", "Guinea-Bissau", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti", "Hungary", "Indonesia", "Ireland", "Israel", "Isle of Man", "India", "British Indian Ocean Territory", "Iraq", "Iran", "Iceland", "Italy", "Jersey", "Jamaica", "Jordan", "Japan", "Kenya", "Kyrgyzstan", "Cambodia", "Kiribati", "Comoros", "Saint Kitts and Nevis", "North Korea", "South Korea", "Kuwait", "Cayman Islands", "Kazakhstan", "Laos", "Lebanon", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Liberia", "Lesotho", "Lithuania", "Luxembourg", "Latvia", "Libya", "Morocco", "Monaco", "Moldova", "Montenegro", "Saint Martin", "Madagascar", "Marshall Islands", "Macedonia", "Mali", "Myanmar [Burma]", "Mongolia", "Macao", "Northern Mariana Islands", "Martinique", "Mauritania", "Montserrat", "Malta", "Mauritius", "Maldives", "Malawi", "Mexico", "Malaysia", "Mozambique", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria", "Nicaragua", "Netherlands", "Norway", "Nepal", "Nauru", "Niue", "New Zealand", "Oman", "Panama", "Peru", "French Polynesia", "Papua New Guinea", "Philippines", "Pakistan", "Poland", "Saint Pierre and Miquelon", "Pitcairn Islands", "Puerto Rico", "Palestine", "Portugal", "Palau", "Paraguay", "Qatar", "R�union", "Romania", "Serbia", "Russia", "Rwanda", "Saudi Arabia", "Solomon Islands", "Seychelles", "Sudan", "Sweden", "Singapore", "Saint Helena", "Slovenia", "Svalbard and Jan Mayen", "Slovakia", "Sierra Leone", "San Marino", "Senegal", "Somalia", "Suriname", "South Sudan", "S�o Tom� and Pr�ncipe", "El Salvador", "Sint Maarten", "Syria", "Swaziland", "Turks and Caicos Islands", "Chad", "French Southern Territories", "Togo", "Thailand", "Tajikistan", "Tokelau", "East Timor", "Turkmenistan", "Tunisia", "Tonga", "Turkey", "Trinidad and Tobago", "Tuvalu", "Taiwan", "Tanzania", "Ukraine", "Uganda", "U.S. Minor Outlying Islands", "United States", "Uruguay", "Uzbekistan", "Vatican City", "Saint Vincent and the Grenadines", "Venezuela", "British Virgin Islands", "U.S. Virgin Islands", "Vietnam", "Vanuatu", "Wallis and Futuna", "Samoa", "Kosovo", "Yemen", "Mayotte", "South Africa", "Zambia", "Zimbabwe"];
    var languagetags = ["Afrikaans", "Albanian", "Arabic", "Armenian", "Azerbaijani", "Bengali", "Bosnian", "Bulgarian", "Catalan", "Chinese", "Croatian", "Czech", "Danish", "Dutch", "English", "Estonian", "Finnish", "French", "Galician", "Georgian", "German", "Greek", "Gujarati", "Hebrew", "Hindi", "Hungarian", "Icelandic", "Indonesian", "Italian", "Japanese", "Kannada", "Kazakh", "Korean", "Latvian", "Lithuanian", "Macedonian", "Malay", "Malayalam", "Marathi", "Mongolian", "Nepali", "Norwegian", "NorwegianNynorsk", "Persian", "Polish", "Portuguese", "Punjabi", "Romanian", "Russian", "Serbian", "Sinhalese", "Slovak", "Slovenian", "Somali", "Spanish", "Swahili", "Swedish", "Tamil", "Telugu", "Thai", "Tibetan", "Turkish", "Ukrainian", "Urdu", "Vietnamese"];

    $("#themes").autocomplete({
        source: function (request, response) {
            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(request.term), "i");
            response($.grep(themetags, function (item) {
                return matcher.test(item);
            }));
        },
        select: function (event, ui) {
            $("#languages").val(``);
            $("#countries").val(``);
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            getGDELT(`sourcelang:eng%20theme:${value}`,250,'6h','datedesc')
            .then(data=>{                
                $("#article_details").css("display:none");
                $("#article_list").css("display:block");
                populate(data);
            })  
            //get_response(`https://api.gdeltproject.org/api/v2/doc/doc?query=&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=1h`).then((data) => { populate_gdelt(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");

        }
    });
    $("#countries").autocomplete({
        source: function (request, response) {
            console.log(request);
            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(request.term), "i");
            response($.grep(countrytags, function (item) {
                return matcher.test(item);
            }));
        },
        select: function (event, ui) {
            $("#languages").val(``);
            $("#themes").val(``);
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            getGDELT(`sourcelang:eng%20sourcecountry:${value}`,250,'6h','datedesc')
            .then(data=>{                
                $("#article_details").css("display:none");
                $("#article_list").css("display:block");
                populate(data);
            })  
            // get_response(`https://api.gdeltproject.org/api/v2/doc/doc?query=sourcelang:eng%20sourcecountry:${value}&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=1h`).then((data) => { populate_gdelt(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");
        }
    });
    $("#languages").autocomplete({
        source: function (request, response) {
            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(request.term), "i");
            response($.grep(languagetags, function (item) {
                return matcher.test(item);
            }));
        },
        select: function (event, ui) {
            $("#countries").val(``);
            $("#themes").val(``);
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            getGDELT(`sourcelang:${value}`,250,'6h','datedesc')
            .then(data=>{                
                $("#article_details").css("display:none");
                $("#article_list").css("display:block");
                populate(data);
            }) 
            // get_response(`https://api.gdeltproject.org/api/v2/doc/doc?query=sourcelang:${value}&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=1h`).then((data) => { populate_gdelt(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");
        }
    });
}
$('#gdelt_keyword').on("input", load_gdelt);
function load_gdelt() {
    var kw = $('#gdelt_keyword').val()
    if (kw == "" || kw.length < 4) {
    } else {
        getGDELT(`sourcelang:eng%20${kw}`,250,'6h','datedesc')
            .then(data=>{                
                $("#article_details").css("display:none");
                $("#article_list").css("display:block");
                populate(data);
            })  
    }

}

//Redditt
function normalizeRedditData(results) {    
    arr = []
    if (Array.isArray(results)){
        for (index in results) {
            results[index].data.children.forEach(item => {
                var item_index = arr.findIndex(x => x.link == item.data.url);
                if (item.data.url.includes("youtube") || item.data.url.includes("youtu.be") || item.data.url.includes("twitter.com") || item.data.url.includes("redd.it") || item.data.url.includes("reddit.com") || item.data.url.includes("imgur.com") || item.data.url.includes("gfycat.com")) {
                    //do nothing
                } else {
                    if (item_index === -1) {
                        arr.push({
                            "title": item.data.title,
                            "created": item.data.created,
                            "link": item.data.url,
                            "source": item.data.domain,
                            "thumbnail": item.data.thumbnail,
                            "iDate": item.data.subreddit,
                        })
                    }
                }
            });
        }
    }else{
        $.each(results.data.children, function(k,item){
            var item_index = arr.findIndex(x => x.link == item.data.url);
            if (item_index === -1) {
                arr.push({
                    "title": item.data.title,
                    "created": item.data.created,
                    "link": item.data.url,
                    "source": item.data.domain,
                    "thumbnail": item.data.thumbnail,
                    "iDate": item.data.subreddit,
                })
            }
        })
    }
   
    arrr = arr.sort(function (a, b) {
        return b.created - a.created;
    });
    return arrr;
}
function getReddit(subreddits) {
    return new Promise((resolve, reject) => {
        try {
            if (!getLocalStorage("topNews")) {
                urls = [
                    // `https://www.reddit.com/r/${subreddits}/top/.json?&t=week&limit=50`,
                    `https://www.reddit.com/r/${subreddits}/top/.json?t=day&limit=50`,
                    `https://www.reddit.com/r/${subreddits}/top/.json?t=hour&limit=50`,
                    `https://www.reddit.com/r/${subreddits}/hot/.json?&t=day&limit=50`,
                    `https://www.reddit.com/r/${subreddits}/hot/.json?&t=hour&limit=50`,
                    // `https://www.reddit.com/r/${subreddits}/hot/.json?&t=week&limit=50`,
                ]
                async.map(urls, async function (url) {
                    try {
                        const response = await fetch(url);
                        return response.json()
                    } catch (err) {
                        return {}
                    }
                }, (err, results) => {
                    // console.log(results)
                    response = normalizeRedditData(results);
                    // console.log(response)
                    setLocalStorage("topNews", response, 15 * 60000);
                    resolve(response);
                })
            } else {
                resolve(getLocalStorage("topNews"));
            }
        } catch (err) { reject(err) }
    })
}
function subreddit_autocomplete() {
    $("#subreddit").autocomplete({
        source: function (request, response) {            
            $.ajax({
                url: "https://www.reddit.com/api/subreddit_autocomplete_v2.json?&raw_json=1&gilding_detail=1&nsfw=1",
                dataType: "json",
                data: {
                    query: request.term
                },
                success: function (data) {
                    response(
                        $.map(data.data.children, function (k, v) {
                            console.log(k, v);
                            return {
                                label: k.data.display_name,
                                value: k.data.display_name
                            };
                        })
                    );
                }
            });
        },
        minLength: 3,
        select: function (event, ui) {
            event.preventDefault();
            $("#subreddit").val(ui.item.label);
            var value = ui.item.label;
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            fetch(`https://www.reddit.com/r/${value}/top/.json?sort=top&t=week&limit=100`)
            .then((response) => response.json())
            .then((data) => {
                results = normalizeRedditData(data);
                populate(results);
            });
            // get_response(`https://www.reddit.com/r/${value}/top/.json?sort=top&t=week&limit=100`).then((data) => { populate_reddit(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");
        },
        focus: function (event, ui) {
            event.preventDefault();
            $("#subreddit").val(ui.item.label);
        }
    });
}

//EMM
//EMM NewsBrief
function normalizeEMM(data){
    console.log(data);
    var arr=[],arrr=[];
    $.each(data.data.items,function(k,item){
        // console.log(item);
        // var {hostname} = new URL(item.mainItemLink);               
        let media = item.media ?  item.media : ``;
        let iDate = timeSince(new Date(item.startDate));
        let published =  Date.parse(item.startDate);
        let title =  item.title ? item.title : ``
        let content =  item.description ? item.description : ``        
        arr.push({
            "title": title,
            "link": item.mainItemLink,
            "content": content,
            "iDate": iDate,
            "media": media,
            "published":published,
        })      
    });
    // console.log(arr);
    arrr = arr.sort(function (a, b) {
        return b.published - a.published;
    });
    return arrr;
}
function normalizeEMMCat(data){
    console.log(data);
    var arr=[],arrr=[];
    $.each(data.data.itemMap,function(k,item){
        // console.log(item);
        // var {hostname} = new URL(item.mainItemLink);               
        let media = item.media ?  item.media : ``;
        let iDate = timeSince(new Date(item.pubDate));
        let published =  Date.parse(item.pubDate);
        let title =  item.title ? item.title : ``
        let content =  item.description ? item.description : ``        
        arr.push({
            "title": title,
            "link": item.link,
            "content": content,
            "iDate": iDate,
            "media": media,
            "published":published,
        })      
    });
    // console.log(arr);
    arrr = arr.sort(function (a, b) {
        return b.published - a.published;
    });
    return arrr;
}
function getEMM(stories){
    return new Promise((resolve, reject)=>{
        try{
            url =  `https://emm.newsbrief.eu/emmMap/tunnel?sid=emmMap&?stories=${stories}&language=en`;                        
            fetchURL(url).then(data=>{
                resolve(normalizeEMM(data));
            })
        }catch(err){reject(err)}
    })
}
function getEMMbyCategory(cat){
    return new Promise((resolve, reject)=>{
        try{
            url =  `https://emm.newsbrief.eu/emmMap/tunnel?sid=emmMap-1&?category=${cat}&rows=100&language=en`;                        
            fetchURL(url).then(data=>{
                resolve(normalizeEMMCat(data));
            })
        }catch(err){reject(err)}
    })
}


const CORS_PROXY = "https://sbcors.herokuapp.com/";

//RSS
function normalizeRSS(data){
    var arr=[], arrr=[];
    $.each(data, function(i,j){
        $.each(j.items, function(k,v){             
            let media = v.media ?  v.media : ``;
            let iDate = v.isoDate ? `${timeSince(new Date(v.isoDate))}` : ``
            let published =  Date.parse(v.isoDate);
            let title =  v.title ? v.title : ``
            let content =  v.content ? v.content : ``
            arr.push({
                "title": title,
                "link": v.link,
                "content": content,
                "iDate": iDate,
                "media": media,
                "published":published,
            })
        });
        arrr = arr.sort(function (a, b) {
            return b.published - a.published;
        });       
    })
    return arrr;  
     
}
function getSingleRSS(url) {
    return new Promise((resolve, reject) => {
        try {           
            let parser = new RSSParser();           
            arr = [];
            parser.parseURL(CORS_PROXY + url, function (err, feed) {
                console.log(feed);
                $.each(feed.items, function(k,v){    
                    var {hostname} = new URL(v.link);               
                    let media = v.media ?  v.media : ``;
                    let iDate = v.isoDate ? `${timeSince(new Date(v.isoDate))}` : ``
                    let published =  Date.parse(v.isoDate);
                    let title =  v.title ? v.title : ``
                    let content =  v.content ? v.content : ``
                    arr.push({
                        "title": title,
                        "link": v.link,
                        "content": content,
                        "iDate": iDate,
                        "media": media,
                        "published":published,
                    })
                });
                var arrr = arr.sort(function (a, b) {
                    return b.published - a.published;
                });
               console.log(arrr)
               resolve(arrr)
            })
        } catch (err) { reject(err) }
    })

}
function getMultipleRSS(urls){
    return new Promise((resolve, reject)=>{
        try{
            let parser = new RSSParser(); 
            async.map(urls, async function (url) {
                try {
                    const response =  await parser.parseURL(CORS_PROXY + url)
                    return response                 
                } catch (err) {
                    return {"err":err}
                }

            }, (err, results) => {
                if (err) { console.log(err); } else { 
                    resolve(normalizeRSS(results))
                }
            })
            
        }catch(err){reject(err)}
    })
}
function rss_autocomplete() {
    $("#subreddit").autocomplete({
        source: function (request, response) {            
            $.ajax({
                url: "https://www.reddit.com/api/subreddit_autocomplete_v2.json?&raw_json=1&gilding_detail=1&nsfw=1",
                dataType: "json",
                data: {
                    query: request.term
                },
                success: function (data) {
                    response(
                        $.map(data.data.children, function (k, v) {
                            console.log(k, v);
                            return {
                                label: k.data.display_name,
                                value: k.data.display_name
                            };
                        })
                    );
                }
            });
        },
        minLength: 3,
        select: function (event, ui) {
            event.preventDefault();
            $("#subreddit").val(ui.item.label);
            var value = ui.item.label;
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            fetch(`https://www.reddit.com/r/${value}/top/.json?sort=top&t=week&limit=100`)
            .then((response) => response.json())
            .then((data) => {
                results = normalizeRedditData(data);
                populate(results);
            });
            // get_response(`https://www.reddit.com/r/${value}/top/.json?sort=top&t=week&limit=100`).then((data) => { populate_reddit(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");
        },
        focus: function (event, ui) {
            event.preventDefault();
            $("#subreddit").val(ui.item.label);
        }
    });
}


//Feedly
//Feedly
function normalizeFeedly(data){
    var arr=[];
    var arrr = [];
    if(Array.isArray(data)){
        for (index in data) {
            //console.log(results[index].title)
            if (data[index].recentEntries) {
                data[index].recentEntries.forEach(item => {
                    let title = item.title ? item.title : ``;
                    let link = item.canonicalUrl ? item.canonicalUrl : ``;
                    let content = item.summary ? item.summary.content : ``
                    let published = item.published ? item.published : ``
                    let media = item.visual ? item.visual.url : ``
                    arr.push({
                        "title": title,
                        "link": link,
                        "content": content,
                        "published": published,
                        "media": media
                    })
                });
            }
            arrr = arr.sort(function (a, b) {
                return b.published - a.published;
            });
        }
    }
    else{
        data.data.recentEntries.forEach(item => {
            let title = item.title ? item.title : ``;
            let link = item.canonicalUrl ? item.canonicalUrl : ``;
            let content = item.summary ? item.summary.content : ``
            let published = item.published ? item.published : ``
            let media = item.visual ? item.visual.url : ``
            arr.push({
                "title": title,
                "link": link,
                "content": content,
                "published": published,
                "media": media
            });
            arrr = arr.sort(function (a, b) {
                return b.published - a.published;
            });
        });
    }
    return arrr;
}
function getFeedlySingle(url, n){    
    return new Promise((resolve, reject) => {
        try {
            url =  `https://feedly.com/v3/feeds/feed%2F${encodeURIComponent(url)}?numRecentEntries=${n}&ck=1656168883401&ct=feedly.desktop&cv=31.0.1621`;                        
            fetchURL(CORS_PROXY + url).then(data=>{
                console.log(data);
                console.log(normalizeFeedly(data));;
                resolve(data);
            })
        } catch (err) { reject(err) }
    })
}
function getFeedlyMultiple(urls,n){    
    return new Promise((resolve, reject) => {
        try {           
            async.map(urls, async function (url) {
                try {
                    url =  `https://feedly.com/v3/feeds/feed%2F${encodeURIComponent(url)}?numRecentEntries=${n}&ck=1656168883401&ct=feedly.desktop&cv=31.0.1621`
                    const response = await fetch(CORS_PROXY + url)
                    return response.json()
                } catch (err) {
                    return {}
                }

            }, (err, results) => {
                if (err) { console.log(err); } else {                   
                    resolve(normalizeFeedly(results));
                }
            })
        } catch (err) { reject(err) }
    })
}
function autocomplete(inp) {var currentFocus; function addActive(x) { if (!x) return !1; removeActive(x), currentFocus >= x.length && (currentFocus = 0), currentFocus < 0 && (currentFocus = x.length - 1), x[currentFocus].classList.add("autocomplete-active") } function removeActive(x) { for (var i = 0; i < x.length; i++)x[i].classList.remove("autocomplete-active") } function closeAllLists(elmnt) { for (var x = document.getElementsByClassName("autocomplete-items"), i = 0; i < x.length; i++)elmnt != x[i] && elmnt != inp && x[i].parentNode.removeChild(x[i]) } inp.addEventListener("input", (function (e) { console.log(this.value); var a, b, i, val = this.value; if (closeAllLists(), !val) return !1; currentFocus = -1, (a = document.createElement("DIV")).setAttribute("id", this.id + "autocomplete-list"), a.setAttribute("class", "autocomplete-items"), this.parentNode.appendChild(a), urls = [`https://sbcors.herokuapp.com/https://feedly.com/v3/search/feeds?q=${val}&n=9&withWebsite=true&autocomplete=true&fullTerm=false&locale=en&ck=1656138724473&ct=feedly.desktop&cv=31.0.1621`], val.length >= 3 && async.mapLimit(urls, 1, (async function (url) { try { const response = await fetch(url); return response.json() } catch (err) { return {} } }), (err, arr) => { for (console.log(arr[0].results), i = 0; i < arr[0].results.length; i++)(b = document.createElement("DIV")).innerHTML = `<img src="${arr[0].results[i].visualUrl}" style="object-fit:cover;max-height:30px;max-width:30px" class="me-2 p-2"/>` + "<strong>" + arr[0].results[i].title + "</strong>", b.innerHTML += "<input type='hidden' value='" + arr[0].results[i].title + "'>", b.innerHTML += "<input type='hidden' value='" + arr[0].results[i].feedId + "'>", b.addEventListener("click", (function (e) { inp.value = this.getElementsByTagName("input")[0].value, $(".content").html(this.getElementsByTagName("input")[0].value), getSingleRSS(this.getElementsByTagName("input")[1].value.replaceAll("feed/","")).then(data => { populate(data) }), closeAllLists() })), a.appendChild(b) }) })), inp.addEventListener("keydown", (function (e) { var x = document.getElementById(this.id + "autocomplete-list"); x && (x = x.getElementsByTagName("div")), 40 == e.keyCode ? (currentFocus++, addActive(x)) : 38 == e.keyCode ? (currentFocus--, addActive(x)) : 13 == e.keyCode && (e.preventDefault(), currentFocus > -1 && x && x[currentFocus].click()) })), document.addEventListener("click", (function (e) { closeAllLists(e.target) })) } autocomplete(document.getElementById("rssfeed"));


//DOM
function populate(data) {
    console.log(data);
    $("#article_list").html(``);
    try {
        $.each(data, function (k, v) {
            if (!v.link.startsWith("/r/")) {
                var { hostname } = new URL(v.link);
                var $listItem = $(`                    
                <li class="tablerow list-group-item px-1" style="cursor: pointer;">
                <div class="row">
                    <div class="col-3 text-primary title">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${hostname}
                    </div>
                    <div class="col-7 text-dark fw-bold title" title="${v.title}">
                        ${v.title}
                    </div>
                    <div class="col-2 d-flex justify-content-end">
                        ${v.iDate}
                    </div>
                </div>
                </li>
                `);
                $listItem.on("click", function (e) {
                    popupWindow(v.link,v.title,screen.width,screen.height);
                    // getArticleExtract(v.link);
                });
                $listItem.on("mouseover", function (e) {
                    //window.open(v.link);
                });
                $("#article_list").append($listItem);
            }

        })
    } catch (err) { console.log(err) }
}

function popupWindow(url, title, w, h) {
    var left = (screen.width / 2) - (w / 2);
    var top = (screen.height / 2) - (h / 2);
    var win = window.open(url, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
    win.focus();
}

function getArticleExtract(url) {
    $("#article_details").html(``);
    async.tryEach([
        (next) => {
            Parse(`${url}`).then(data => {
                if (data.title) {                   
                    source_url = new URL(url);
                    update_HTML(data, source_url);
                } else {
                    console.log(`Simple parsing did not work`);
                    return next(new Error('Cannot get Data'))
                }
            }).catch(err => {
                console.log(err);                
                return next(new Error('Cannot get Data'))
            })
        },
        (next) => {
            console.log(`Simple parsing did not work..trying with CORS..`)
            Parse(`https://sbcors.herokuapp.com/${url}`).then(data => {
                if (data.title) {                   
                    source_url = new URL(url);
                    update_HTML(data, source_url);
                } else {
                    console.log(`CORS did not work`);                    
                    return next(new Error('Cannot get Data'))
                }
            }).catch(err => {      
                console.log(`Cannot get Data ${err}`)         
                return next(new Error(`Cannot get Data ${err}`))
            })
        },
        (next) => {
            window.open(url)
        },
    ])
}

function update_HTML(data, source_url) {  
    console.clear();
    console.log(data);    
    $("#article_details").append(`<div class="mb-2 ms-0 d-flex">
    <button type="button" class="btn btn-sm btn-outline-dark closeButton"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                              </svg> Back</button>
    </div>`);
    $("#article_details").append(`<img alt="${source_url.hostname}" class="mt-1 mb-3" src="https://www.google.com/s2/favicons?domain=${source_url.hostname}" /><span class="small"> ${source_url.hostname.replace("http://", "").replace("https://", "").replace("www.", "")}</span>`);
    $("#article_details").append(`<h1>${data.title}</h1>`);
    if (data.date_published) {
        $("#article_details").append(`<p class="small m-2">${data.date_published.split('T')[0]}</p>`);
    }
    $("#article_details").append(`<hr class="my-3"></hr>`);
    $("#article_details").append(`<p class="small">${data.content}<p>`);
    $("#article_details").append(`<div class="mb-2 ms-0 d-flex"> <button type="button" class="btn btn-sm btn-outline-dark closeButton"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
  </svg> Back</button></div>`);
    $("#article_details").toggle();;
    $("#article_list").toggle();;
    $(".closeButton").on("click", function(e){       
        $("#article_details").toggle();;
        $("#article_list").toggle();;
    })
}