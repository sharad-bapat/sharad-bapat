GLOBALS = {};

function setLocalStorage(key, value, ttl) {
    const now = new Date();
    const item = {
        value: value,
        expiry: now.getTime() + ttl
    };
    localStorage.setItem(key, JSON.stringify(item));
}
function getLocalStorage(key) {
    const itemStr = localStorage.getItem(key);
    if (!itemStr) {
        return null;
    }
    const item = JSON.parse(itemStr);
    const now = new Date();
    if (now.getTime() > item.expiry) {
        localStorage.removeItem(key);
        return null;
    }
    return item.value;
}
Storage.prototype.deleteLocalStorage = function (key) {
    this.removeItem(key);
}
Storage.prototype.clear = function () {
    this.clear();
}
function get_localstorage_size() {
    var _lsTotal = 0,
        _xLen, _x;
    for (_x in localStorage) {
        if (!localStorage.hasOwnProperty(_x)) {
            continue;
        }
        _xLen = ((localStorage[_x].length + _x.length) * 2);
        _lsTotal += _xLen;
        console.log(_x.substr(0, 50) + " = " + (_xLen / 1024).toFixed(2) + " KB")
    };
    console.log("Total = " + (_lsTotal / 1024).toFixed(2) + " KB");
}
function get_response(url) {
    return new Promise((resolve, reject) => {
        $.ajax({
            type: 'GET',
            url: url,
            success: function (data) {
                resolve(data);
            },
            error: function (e) { reject(e); }
        });
    })
}
function parse_using_panda(url, pubdate, title) {
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    $(".tablerow").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    var { hostname } = new URL(url);
    $.ajax({
        type: 'GET',
        url: `https://api-panda.com/v2/feeds/story/full?url=${url}`,
        success: function (data) {
            if (typeof data.data !== 'undefined') {
                $("#article_details").html(`<li class="list-group-item"><img src="https://www.google.com/s2/favicons?sz=24&domain=${hostname}" alt="" width="24" class="rounded-circle" />&nbsp;${title} <span class="small text-muted">${pubdate}</span></li>`);
                $("#article_details").append(`<li class="list-group-item">${data.data.html}</li>`)
            } else {
                $(".article_details").append(`<li class="mt-1">We cannot parse this url. Please visit the source directly. <a href="${url}" target="_blank">Source</a></li>`);
                $(".article_details").append(`<hr>`);
            }
            $("#backbutton").attr("hidden", false);
            $("#article_details").attr("hidden", false);
            $("#article_list").attr("hidden", true);
            $(".main").attr("style", "");
            $(".tablerow").attr("style", "cursor: pointer;");
            $(".main").animate({ scrollTop: 0 }, "fast");
        },
        error: function (e) { console.log(e); }
    });
}
function toogle_list() {
    $(".main").animate({ scrollTop: 0 }, "fast");
    $("#backbutton").attr("hidden", true);
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    $(".main").attr("style", "");
    $(".tablerow").attr("style", "cursor: pointer;");
}

function htmlDecode(input) {
    var doc = new DOMParser().parseFromString(input, "text/html");
    return doc.documentElement.textContent;
}

// $(function () {    
//     if (!getLocalStorage("defaults")) {       
//         get_response("http://localhost:9999/defaults/").then((data) => { setLocalStorage("defaults", data, 30 * 60000); GLOBALS.defaults = data;get_localstorage_size();get_localstorage_size() });
//     } else {        
//         GLOBALS.defaults = getLocalStorage("r_worldnews_hour");
//     }
//     console.log(GLOBALS);
//     populate_reddit(GLOBALS.defaults.r_worldnews_hour);

// });

// $(function old() {
//     // get_response("http://localhost:9999/defaults/").then((data) => { setLocalStorage("defaults", data, 1 * 60000); GLOBALS.defaults = data;get_localstorage_size();get_localstorage_size() });
//     // localStorage.clear();
//     get_localstorage_size();
//     update_gdelt_autocomplete();
//     subreddit_autocomplete();
//     // localStorage.deleteLocalStorage("wiki_trends ");
//     // get_localstorage_size();
//     // localStorage.deleteLocalStorage("wiki_trends ");
//     // localStorage.clear();
//     if (!getLocalStorage("emm_top")) {
//         // console.log("Fetching EMM Top from server");
//         get_response("https://emm.newsbrief.eu/emmMap/tunnel?sid=emmMap&?stories=top&language=en").then((data) => { setLocalStorage("emm_top", data, 15 * 60000); GLOBALS.emm_top = data; });
//     } else {
//         // console.log("Fetching EMM Top from local storage");
//         GLOBALS.emm_top = getLocalStorage("emm_top");

//     }
//     if (!getLocalStorage("emm_events")) {
//         // console.log("Fetching EMM Events from server");
//         get_response("https://emm.newsbrief.eu/emmMap/tunnel?sid=emmMap&?stories=events&language=en").then((data) => { setLocalStorage("emm_events", data, 30 * 60000); GLOBALS.emm_events = data; });
//     } else {
//         // console.log("Fetching EMM Events from local storage");
//         GLOBALS.emm_events = getLocalStorage("emm_events");
//     }
//     if (!getLocalStorage("emm_india")) {
//         // console.log("Fetching EMM India from server");
//         get_response("https://emm.newsbrief.eu/emmMap/tunnel?sid=emmMap-1&?category=India&rows=100&language=en").then((data) => { setLocalStorage("emm_india", data, 30 * 60000); GLOBALS.emm_india = data; });
//     } else {
//         // console.log("Fetching EMM India from local storage");
//         GLOBALS.emm_india = getLocalStorage("emm_india");
//     }
//     if (!getLocalStorage("emm_uk")) {
//         // console.log("Fetching EMM UK from server");
//         get_response("https://emm.newsbrief.eu/emmMap/tunnel?sid=emmMap-1&?category=UNitedKingdom&rows=100&language=en").then((data) => { setLocalStorage("emm_uk", data, 30 * 60000); GLOBALS.emm_uk = data; });
//     } else {
//         // console.log("Fetching EMM UK from local storage");
//         GLOBALS.emm_uk = getLocalStorage("emm_uk");
//     }
//     if (!getLocalStorage("r_worldnews_hour")) {
//         // console.log("Fetching r_worldnews_hour from server");
//         get_response("https://www.reddit.com/r/worldnews/top/.json?sort=top&t=hour").then((data) => { setLocalStorage("r_worldnews_hour", data, 60 * 60000); GLOBALS.r_worldnews_hour = data; });
//     } else {
//         // console.log("Fetching r_worldnews_hour from local storage");
//         GLOBALS.r_worldnews_hour = getLocalStorage("r_worldnews_hour");
//     }
//     if (!getLocalStorage("r_worldnews_day")) {
//         // console.log("Fetching r_worldnews_day from server");
//         get_response("https://www.reddit.com/r/worldnews/top/.json?sort=top&t=day").then((data) => { setLocalStorage("r_worldnews_day", data, 3 * 60 * 60000); GLOBALS.r_worldnews_day = data; });
//     } else {
//         // console.log("Fetching r_worldnews_day from local storage");
//         GLOBALS.r_worldnews_day = getLocalStorage("r_worldnews_day");
//     }
//     if (!getLocalStorage("r_worldnews_rising")) {
//         // console.log("Fetching r_worldnews_rising from server");
//         get_response("https://www.reddit.com/r/worldnews/rising/.json").then((data) => { setLocalStorage("r_worldnews_rising", data, 15 * 60000); GLOBALS.r_worldnews_rising = data; });
//     } else {
//         // console.log("Fetching r_worldnews_rising from local storage");
//         GLOBALS.r_worldnews_rising = getLocalStorage("r_worldnews_rising");
//     }
//     if (!getLocalStorage("r_all")) {
//         // console.log("Fetching r_all from server");
//         get_response("https://www.reddit.com/r/all/top/.json?sort=top&t=hour").then((data) => { setLocalStorage("r_all", data, 15 * 60000); GLOBALS.r_all = data; });
//     } else {
//         // console.log("Fetching r_damnthatsinteresting from local storage");
//         GLOBALS.r_all = getLocalStorage("r_all");
//     }
//     if (!getLocalStorage("google_trends")) {
//         // console.log("Fetching google_trends from server");
//         get_google_trends("IN").then((data) => { setLocalStorage("google_trends", data, 60 * 60000); GLOBALS.google_trends = data; });
//         // get_response("https://www.reddit.com/r/worldnews/rising/.json")
//     } else {
//         // console.log("Fetching google_trends from local storage");
//         GLOBALS.google_trends = getLocalStorage("google_trends");
//     }
//     if (!getLocalStorage("otd")) {
//         // console.log("Fetching On this day from server");
//         const d = new Date();
//         year = d.getFullYear();
//         month = d.getMonth() + 1;
//         day = d.getDate();
//         if (month < 10) { month = "0" + month }
//         if (day < 10) { day = "0" + day }
//         url = "https://en.wikipedia.org/api/rest_v1/feed/onthisday/all/" + month + "/" + day;
//         get_response(url).then((data) => { setLocalStorage("otd", data, 6 * 60 * 60000); GLOBALS.otd = data; });

//     } else {
//         // console.log("Fetching  On this day  from local storage");
//         GLOBALS.otd = getLocalStorage("otd");
//     }
//     if (!getLocalStorage("wiki_trends")) {
//         // console.log("Fetching google_trends from server");
//         get_wiki_trends("IN").then((data) => { setLocalStorage("wiki_trends", data, 6 * 60 * 60000); GLOBALS.wiki_trends = data; });
//         // get_response("https://www.reddit.com/r/worldnews/rising/.json")
//     } else {
//         // console.log("Fetching google_trends from local storage");
//         GLOBALS.wiki_trends = getLocalStorage("wiki_trends");
//     }

//     if (!getLocalStorage("twitter_trends")) {  
//         const d = new Date();
//         year = d.getFullYear();
//         month = d.getMonth() + 1;
//         day = d.getDate() - 1;
//         if (month < 10) { month = "0" + month }
//         if (day < 10) { day = "0" + day }     
//         get_response(`http://sbcors.herokuapp.com/https://api.exportdata.io/trends/locations/in?date=2021-${day}-${month}`).then((data) => { setLocalStorage("twitter_trends", data, 30 * 60000); GLOBALS.twitter_trends = data; });

//     } else {
//         // console.log("Fetching google_trends from local storage");
//         GLOBALS.twitter_trends = getLocalStorage("twitter_trends");
//     }

//     if (!getLocalStorage("reddit_trends")) {
//         // console.log("Fetching r_all from server");
//         get_response("https://www.reddit.com/api/trending_searches_v1.json?withAds=0&raw_json=1&gilding_detail=1").then((data) => { setLocalStorage("reddit_trends", data, 15 * 60000); GLOBALS.reddit_trends = data; });
//     } else {
//         // console.log("Fetching r_damnthatsinteresting from local storage");
//         GLOBALS.reddit_trends = getLocalStorage("reddit_trends");
//     }

//     console.log(GLOBALS);
//     populate_reddit(GLOBALS.r_worldnews_hour);

// });

// EMM Functions

$('#a_emm_top').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_emm(GLOBALS.emm_top);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});
$('#a_emm_events').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_emm(GLOBALS.emm_events);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});
$('#a_emm_india').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_emm_map(GLOBALS.emm_india);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});
$('#a_emm_uk').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_emm_map(GLOBALS.emm_uk);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});
function populate_emm(data) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    if (typeof data.items !== 'undefined') {
        $.each(data.items, function (key, value) {
            // 2021-08-30T22:26+0200
            // 2021 7 -3 T2
            // `<details class="mb-1"><summary>${value.title}</summary><p class="p-1">${value.description}</span> | ${da}-${mo}-${ye}</p>`,
            var d = new Date(value.pubDate.substr(0, 4), value.pubDate.substr(5, 2) - 1, value.pubDate.substr(8, 2));
            let ye = new Intl.DateTimeFormat('en', { year: 'numeric' }).format(d);
            let mo = new Intl.DateTimeFormat('en', { month: '2-digit' }).format(d);
            let da = new Intl.DateTimeFormat('en', { day: '2-digit' }).format(d);
            title = value.title.replace(/(\r\n|\n|\r)/gm, "");
            title = title.replaceAll(/'/g, "");
            title = title.replaceAll(/"/g, "");
            title = title.replaceAll(/'/g, "\\'");
            top_stories_html = top_stories_html.concat(`
                <li class="tablerow list-group-item px-1" onclick="javascript:parse_using_panda('${value.mainItemLink}','${value.pubDate}','${title}')" style="cursor: pointer;">                
                <div class="row">
                    <div class="col-2 text-primary fw-bold title">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${value.mainItemSource.value}
                    </div>
                    <div class="col-9 text-muted fw-bold title">
                        ${value.title}
                    </div>
                    <div class="col-1 d-flex justify-content-end text-end">${value.mainItemSource.country}</div>
                </div>                
                </li>
            `);
        });
        $("#article_list").html(top_stories_html);
    }
}
function populate_emm_map(data) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    if (typeof data.itemMap !== 'undefined') {
        $.each(data.itemMap, function (key, value) {
            // 2021-08-30T22:26+0200
            // 2021 7 -3 T2
            // `<details class="mb-1"><summary>${value.title}</summary><p class="p-1">${value.description}</span> | ${da}-${mo}-${ye}</p>`,
            var d = new Date(value.pubDate.substr(0, 4), value.pubDate.substr(5, 2) - 1, value.pubDate.substr(8, 2));
            let ye = new Intl.DateTimeFormat('en', { year: 'numeric' }).format(d);
            let mo = new Intl.DateTimeFormat('en', { month: '2-digit' }).format(d);
            let da = new Intl.DateTimeFormat('en', { day: '2-digit' }).format(d);
            title = value.title.replace(/(\r\n|\n|\r)/gm, "");
            title = title.replaceAll(/'/g, "");
            title = title.replaceAll(/"/g, "");
            title = title.replaceAll(/'/g, "\\'");
            top_stories_html = top_stories_html.concat(`
                <li class="tablerow list-group-item px-1" onclick="javascript:parse_using_panda('${value.link}','${value.pubDate}','${title}')" style="cursor: pointer;">
                <div class="row">
                    <div class="col-3 text-primary fw-bold title">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${value.source.value}
                    </div>
                    <div class="col-8 text-muted fw-bold title">
                        ${value.title}
                    </div>
                    <div class="col-1 d-flex justify-content-end">${value.source.country}</div>
                </div>
                </li>
            `);
        });
        $("#article_list").html(top_stories_html);
    }
}

// GDELT Functions
function update_gdelt_autocomplete() {
    var themetags = ["AFFECT", "AGRICULTURE", "ALLIANCE", "APPOINTMENT", "ARMEDCONFLICT", "ARREST", "ASSASSINATION", "AUSTERITY", "BAN", "BLOCKADE", "BORDER", "BULLYING", "CEASEFIRE", "CHECKPOINT", "CLOSURE", "CONFISCATION", "CONSTITUTIONAL", "CORRUPTION", "CURFEW", "DEFECTION", "DELAY", "DEMOCRACY", "DISABILITY", "DISCRIMINATION", "DISPLACED", "DRONES", "EDUCATION", "ELECTION", "EVACUATION", "EXHUMATION", "EXILE", "EXTREMISM", "FREESPEECH", "FUELPRICES", "GENTRIFICATION", "GRIEVANCES", "HARASSMENT", "IDEOLOGY", "IMMIGRATION", "IMPEACHMENT", "INEQUALITY", "INSURGENCY", "JIHAD", "JUSTICE", "KIDNAP", "KILL", "LANDMINE", "LEADER", "LEGALIZE", "LEGISLATION", "LGBT", "LITERACY", "LOCUSTS", "MARITIME", "MEDICAL", "MILITARY", "NEGOTIATIONS", "PEACEKEEPING", "PERSECUTION", "PIRACY", "POVERTY", "PRIVATIZATION", "PROPAGANDA", "PROTEST", "RAPE", "RATIFY", "REBELLION", "REBELS", "RECRUITMENT", "REFUGEES", "RELATIONS", "RELIGION", "RESIGNATION", "RETALIATE", "RETIREMENT", "RETIREMENTS", "RURAL", "SANCTIONS", "SANITATION", "SCANDAL", "SCIENCE", "SEIGE", "SEIZE", "SEPARATISTS", "SHORTAGE", "SICKENED", "SLUMS", "SMUGGLING", "SOVEREIGNTY", "STRIKE", "SURVEILLANCE", "TERROR", "TORTURE", "TOURISM", "TRAFFIC", "TRANSPARENCY", "TREASON", "TRIAL", "UNEMPLOYMENT", "UNGOVERNED", "URBAN", "VANDALIZE", "VETO", "WHISTLEBLOWER", "WMD", "WOUND"];
    var countrytags = ["Andorra", "United Arab Emirates", "Afghanistan", "Antigua and Barbuda", "Anguilla", "Albania", "Armenia", "Angola", "Antarctica", "Argentina", "American Samoa", "Austria", "Australia", "Aruba", "�land", "Azerbaijan", "Bosnia and Herzegovina", "Barbados", "Bangladesh", "Belgium", "Burkina Faso", "Bulgaria", "Bahrain", "Burundi", "Benin", "Saint Barth�lemy", "Bermuda", "Brunei", "Bolivia", "Bonaire", "Brazil", "Bahamas", "Bhutan", "Bouvet Island", "Botswana", "Belarus", "Belize", "Canada", "Cocos [Keeling] Islands", "Congo", "Central African Republic", "Republic of the Congo", "Switzerland", "Ivory Coast", "Cook Islands", "Chile", "Cameroon", "China", "Colombia", "Costa Rica", "Cuba", "Cape Verde", "Curacao", "Christmas Island", "Cyprus", "Czechia", "Germany", "Djibouti", "Denmark", "Dominica", "Dominican Republic", "Algeria", "Ecuador", "Estonia", "Egypt", "Western Sahara", "Eritrea", "Spain", "Ethiopia", "Finland", "Fiji", "Falkland Islands", "Micronesia", "Faroe Islands", "France", "Gabon", "United Kingdom", "Grenada", "Georgia", "French Guiana", "Guernsey", "Ghana", "Gibraltar", "Greenland", "Gambia", "Guinea", "Guadeloupe", "Equatorial Guinea", "Greece", "South Georgia and the South Sandwich Islands", "Guatemala", "Guam", "Guinea-Bissau", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti", "Hungary", "Indonesia", "Ireland", "Israel", "Isle of Man", "India", "British Indian Ocean Territory", "Iraq", "Iran", "Iceland", "Italy", "Jersey", "Jamaica", "Jordan", "Japan", "Kenya", "Kyrgyzstan", "Cambodia", "Kiribati", "Comoros", "Saint Kitts and Nevis", "North Korea", "South Korea", "Kuwait", "Cayman Islands", "Kazakhstan", "Laos", "Lebanon", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Liberia", "Lesotho", "Lithuania", "Luxembourg", "Latvia", "Libya", "Morocco", "Monaco", "Moldova", "Montenegro", "Saint Martin", "Madagascar", "Marshall Islands", "Macedonia", "Mali", "Myanmar [Burma]", "Mongolia", "Macao", "Northern Mariana Islands", "Martinique", "Mauritania", "Montserrat", "Malta", "Mauritius", "Maldives", "Malawi", "Mexico", "Malaysia", "Mozambique", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria", "Nicaragua", "Netherlands", "Norway", "Nepal", "Nauru", "Niue", "New Zealand", "Oman", "Panama", "Peru", "French Polynesia", "Papua New Guinea", "Philippines", "Pakistan", "Poland", "Saint Pierre and Miquelon", "Pitcairn Islands", "Puerto Rico", "Palestine", "Portugal", "Palau", "Paraguay", "Qatar", "R�union", "Romania", "Serbia", "Russia", "Rwanda", "Saudi Arabia", "Solomon Islands", "Seychelles", "Sudan", "Sweden", "Singapore", "Saint Helena", "Slovenia", "Svalbard and Jan Mayen", "Slovakia", "Sierra Leone", "San Marino", "Senegal", "Somalia", "Suriname", "South Sudan", "S�o Tom� and Pr�ncipe", "El Salvador", "Sint Maarten", "Syria", "Swaziland", "Turks and Caicos Islands", "Chad", "French Southern Territories", "Togo", "Thailand", "Tajikistan", "Tokelau", "East Timor", "Turkmenistan", "Tunisia", "Tonga", "Turkey", "Trinidad and Tobago", "Tuvalu", "Taiwan", "Tanzania", "Ukraine", "Uganda", "U.S. Minor Outlying Islands", "United States", "Uruguay", "Uzbekistan", "Vatican City", "Saint Vincent and the Grenadines", "Venezuela", "British Virgin Islands", "U.S. Virgin Islands", "Vietnam", "Vanuatu", "Wallis and Futuna", "Samoa", "Kosovo", "Yemen", "Mayotte", "South Africa", "Zambia", "Zimbabwe"];
    var languagetags = ["Afrikaans", "Albanian", "Arabic", "Armenian", "Azerbaijani", "Bengali", "Bosnian", "Bulgarian", "Catalan", "Chinese", "Croatian", "Czech", "Danish", "Dutch", "English", "Estonian", "Finnish", "French", "Galician", "Georgian", "German", "Greek", "Gujarati", "Hebrew", "Hindi", "Hungarian", "Icelandic", "Indonesian", "Italian", "Japanese", "Kannada", "Kazakh", "Korean", "Latvian", "Lithuanian", "Macedonian", "Malay", "Malayalam", "Marathi", "Mongolian", "Nepali", "Norwegian", "NorwegianNynorsk", "Persian", "Polish", "Portuguese", "Punjabi", "Romanian", "Russian", "Serbian", "Sinhalese", "Slovak", "Slovenian", "Somali", "Spanish", "Swahili", "Swedish", "Tamil", "Telugu", "Thai", "Tibetan", "Turkish", "Ukrainian", "Urdu", "Vietnamese"];

    $("#themes").autocomplete({
        source: function (request, response) {
            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(request.term), "i");
            response($.grep(themetags, function (item) {
                return matcher.test(item);
            }));
        },
        select: function (event, ui) {
            $("#languages").val(``);
            $("#countries").val(``);
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            get_response(`https://api.gdeltproject.org/api/v2/doc/doc?query=sourcelang:eng%20theme:${value}&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=1h`).then((data) => { populate_gdelt(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");

        }
    });
    $("#countries").autocomplete({
        source: function (request, response) {
            console.log(request);
            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(request.term), "i");
            response($.grep(countrytags, function (item) {
                return matcher.test(item);
            }));
        },
        select: function (event, ui) {
            $("#languages").val(``);
            $("#themes").val(``);
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            get_response(`https://api.gdeltproject.org/api/v2/doc/doc?query=sourcelang:eng%20sourcecountry:${value}&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=1h`).then((data) => { populate_gdelt(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");
        }
    });
    $("#languages").autocomplete({
        source: function (request, response) {
            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(request.term), "i");
            response($.grep(languagetags, function (item) {
                return matcher.test(item);
            }));
        },
        select: function (event, ui) {
            $("#countries").val(``);
            $("#themes").val(``);
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            get_response(`https://api.gdeltproject.org/api/v2/doc/doc?query=sourcelang:${value}&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=1h`).then((data) => { populate_gdelt(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");
        }
    });
}
$('#gdelt_keyword').on("input", load_gdelt);
function load_gdelt() {
    var kw = $('#gdelt_keyword').val()
    if (kw == "" || kw.length < 4) {
    } else {
        $("#article_list").html("");
        $.ajax({
            type: 'GET',
            url: `https://api.gdeltproject.org/api/v2/doc/doc?query=${kw}%20sourcelang:eng&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=6h`,
            success: function (data) {
                console.log(data);
                populate_gdelt(data);
            },
            error: function (e) { console.log(e); }
        });
        $(".main").attr("style", "");
        $(".content").animate({ scrollTop: 0 }, "fast");
    }

}
function gdelt_autocomplete() {
    var themetags = ["AFFECT", "AGRICULTURE", "ALLIANCE", "APPOINTMENT", "ARMEDCONFLICT", "ARREST", "ASSASSINATION", "AUSTERITY", "BAN", "BLOCKADE", "BORDER", "BULLYING", "CEASEFIRE", "CHECKPOINT", "CLOSURE", "CONFISCATION", "CONSTITUTIONAL", "CORRUPTION", "CURFEW", "DEFECTION", "DELAY", "DEMOCRACY", "DISABILITY", "DISCRIMINATION", "DISPLACED", "DRONES", "EDUCATION", "ELECTION", "EVACUATION", "EXHUMATION", "EXILE", "EXTREMISM", "FREESPEECH", "FUELPRICES", "GENTRIFICATION", "GRIEVANCES", "HARASSMENT", "IDEOLOGY", "IMMIGRATION", "IMPEACHMENT", "INEQUALITY", "INSURGENCY", "JIHAD", "JUSTICE", "KIDNAP", "KILL", "LANDMINE", "LEADER", "LEGALIZE", "LEGISLATION", "LGBT", "LITERACY", "LOCUSTS", "MARITIME", "MEDICAL", "MILITARY", "NEGOTIATIONS", "PEACEKEEPING", "PERSECUTION", "PIRACY", "POVERTY", "PRIVATIZATION", "PROPAGANDA", "PROTEST", "RAPE", "RATIFY", "REBELLION", "REBELS", "RECRUITMENT", "REFUGEES", "RELATIONS", "RELIGION", "RESIGNATION", "RETALIATE", "RETIREMENT", "RETIREMENTS", "RURAL", "SANCTIONS", "SANITATION", "SCANDAL", "SCIENCE", "SEIGE", "SEIZE", "SEPARATISTS", "SHORTAGE", "SICKENED", "SLUMS", "SMUGGLING", "SOVEREIGNTY", "STRIKE", "SURVEILLANCE", "TERROR", "TORTURE", "TOURISM", "TRAFFIC", "TRANSPARENCY", "TREASON", "TRIAL", "UNEMPLOYMENT", "UNGOVERNED", "URBAN", "VANDALIZE", "VETO", "WHISTLEBLOWER", "WMD", "WOUND"];
    var countrytags = ["Andorra", "United Arab Emirates", "Afghanistan", "Antigua and Barbuda", "Anguilla", "Albania", "Armenia", "Angola", "Antarctica", "Argentina", "American Samoa", "Austria", "Australia", "Aruba", "�land", "Azerbaijan", "Bosnia and Herzegovina", "Barbados", "Bangladesh", "Belgium", "Burkina Faso", "Bulgaria", "Bahrain", "Burundi", "Benin", "Saint Barth�lemy", "Bermuda", "Brunei", "Bolivia", "Bonaire", "Brazil", "Bahamas", "Bhutan", "Bouvet Island", "Botswana", "Belarus", "Belize", "Canada", "Cocos [Keeling] Islands", "Congo", "Central African Republic", "Republic of the Congo", "Switzerland", "Ivory Coast", "Cook Islands", "Chile", "Cameroon", "China", "Colombia", "Costa Rica", "Cuba", "Cape Verde", "Curacao", "Christmas Island", "Cyprus", "Czechia", "Germany", "Djibouti", "Denmark", "Dominica", "Dominican Republic", "Algeria", "Ecuador", "Estonia", "Egypt", "Western Sahara", "Eritrea", "Spain", "Ethiopia", "Finland", "Fiji", "Falkland Islands", "Micronesia", "Faroe Islands", "France", "Gabon", "United Kingdom", "Grenada", "Georgia", "French Guiana", "Guernsey", "Ghana", "Gibraltar", "Greenland", "Gambia", "Guinea", "Guadeloupe", "Equatorial Guinea", "Greece", "South Georgia and the South Sandwich Islands", "Guatemala", "Guam", "Guinea-Bissau", "Guyana", "Hong Kong", "Heard Island and McDonald Islands", "Honduras", "Croatia", "Haiti", "Hungary", "Indonesia", "Ireland", "Israel", "Isle of Man", "India", "British Indian Ocean Territory", "Iraq", "Iran", "Iceland", "Italy", "Jersey", "Jamaica", "Jordan", "Japan", "Kenya", "Kyrgyzstan", "Cambodia", "Kiribati", "Comoros", "Saint Kitts and Nevis", "North Korea", "South Korea", "Kuwait", "Cayman Islands", "Kazakhstan", "Laos", "Lebanon", "Saint Lucia", "Liechtenstein", "Sri Lanka", "Liberia", "Lesotho", "Lithuania", "Luxembourg", "Latvia", "Libya", "Morocco", "Monaco", "Moldova", "Montenegro", "Saint Martin", "Madagascar", "Marshall Islands", "Macedonia", "Mali", "Myanmar [Burma]", "Mongolia", "Macao", "Northern Mariana Islands", "Martinique", "Mauritania", "Montserrat", "Malta", "Mauritius", "Maldives", "Malawi", "Mexico", "Malaysia", "Mozambique", "Namibia", "New Caledonia", "Niger", "Norfolk Island", "Nigeria", "Nicaragua", "Netherlands", "Norway", "Nepal", "Nauru", "Niue", "New Zealand", "Oman", "Panama", "Peru", "French Polynesia", "Papua New Guinea", "Philippines", "Pakistan", "Poland", "Saint Pierre and Miquelon", "Pitcairn Islands", "Puerto Rico", "Palestine", "Portugal", "Palau", "Paraguay", "Qatar", "R�union", "Romania", "Serbia", "Russia", "Rwanda", "Saudi Arabia", "Solomon Islands", "Seychelles", "Sudan", "Sweden", "Singapore", "Saint Helena", "Slovenia", "Svalbard and Jan Mayen", "Slovakia", "Sierra Leone", "San Marino", "Senegal", "Somalia", "Suriname", "South Sudan", "S�o Tom� and Pr�ncipe", "El Salvador", "Sint Maarten", "Syria", "Swaziland", "Turks and Caicos Islands", "Chad", "French Southern Territories", "Togo", "Thailand", "Tajikistan", "Tokelau", "East Timor", "Turkmenistan", "Tunisia", "Tonga", "Turkey", "Trinidad and Tobago", "Tuvalu", "Taiwan", "Tanzania", "Ukraine", "Uganda", "U.S. Minor Outlying Islands", "United States", "Uruguay", "Uzbekistan", "Vatican City", "Saint Vincent and the Grenadines", "Venezuela", "British Virgin Islands", "U.S. Virgin Islands", "Vietnam", "Vanuatu", "Wallis and Futuna", "Samoa", "Kosovo", "Yemen", "Mayotte", "South Africa", "Zambia", "Zimbabwe"];
    var languagetags = ["Afrikaans", "Albanian", "Arabic", "Armenian", "Azerbaijani", "Bengali", "Bosnian", "Bulgarian", "Catalan", "Chinese", "Croatian", "Czech", "Danish", "Dutch", "English", "Estonian", "Finnish", "French", "Galician", "Georgian", "German", "Greek", "Gujarati", "Hebrew", "Hindi", "Hungarian", "Icelandic", "Indonesian", "Italian", "Japanese", "Kannada", "Kazakh", "Korean", "Latvian", "Lithuanian", "Macedonian", "Malay", "Malayalam", "Marathi", "Mongolian", "Nepali", "Norwegian", "NorwegianNynorsk", "Persian", "Polish", "Portuguese", "Punjabi", "Romanian", "Russian", "Serbian", "Sinhalese", "Slovak", "Slovenian", "Somali", "Spanish", "Swahili", "Swedish", "Tamil", "Telugu", "Thai", "Tibetan", "Turkish", "Ukrainian", "Urdu", "Vietnamese"];

    $("#themes").autocomplete({
        source: function (request, response) {
            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(request.term), "i");
            response($.grep(themetags, function (item) {
                return matcher.test(item);
            }));
        },
        select: function (event, ui) {
            $("#article_list").html("");
            $("#languages").val(``);
            $("#countries").val(``);
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            get_response(`https://api.gdeltproject.org/api/v2/doc/doc?query=sourcelang:eng%20theme:${value}&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=6h`).then((data) => { populate_gdelt(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");

        }
    });
    $("#countries").autocomplete({
        source: function (request, response) {
            console.log(request);
            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(request.term), "i");
            response($.grep(countrytags, function (item) {
                return matcher.test(item);
            }));
        },
        select: function (event, ui) {
            $("#article_list").html("");
            $("#languages").val(``);
            $("#themes").val(``);
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            get_response(`https://api.gdeltproject.org/api/v2/doc/doc?query=sourcelang:eng%20sourcecountry:${value}&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=1h`).then((data) => { populate_gdelt(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");
        }
    });
    $("#languages").autocomplete({
        source: function (request, response) {
            var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(request.term), "i");
            response($.grep(languagetags, function (item) {
                return matcher.test(item);
            }));
        },
        select: function (event, ui) {
            $("#article_list").html("");
            $("#countries").val(``);
            $("#themes").val(``);
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            get_response(`https://api.gdeltproject.org/api/v2/doc/doc?query=sourcelang:${value}&mode=artlist&maxrecords=250&sort=hybridrel&format=json&timespan=6h`).then((data) => { populate_gdelt(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");
        }
    });
}
function populate_gdelt(data) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    var newArray = [];
    if (typeof data.articles !== 'undefined') {
        $.each(data.articles, function (key, value) {
            var exists = false;
            $.each(newArray, function (k, val2) {
                if (value.title.toUpperCase().substring(0, 25) == val2.title.toUpperCase().substring(0, 25)) { exists = true };
            });
            if (exists == false && value.title != "") { newArray.push(value); }
        });
        $.each(newArray, function (key, value) {
            var country = '';
            if (value.sourcecountry == "United States") {
                country = "US";
            } else if (value.sourcecountry == "United Kingdom") {
                country = "UK";
            } else if (value.sourcecountry == "South Africa") {
                country = "SA";
            } else {
                country = value.sourcecountry;
            }
            title = value.title.replace(/(\r\n|\n|\r)/gm, "");
            title = title.replaceAll(/'/g, "");
            title = title.replaceAll(/"/g, "");
            title = title.replaceAll(/'/g, "\\'");
            top_stories_html = top_stories_html.concat(`
            <li class="tablerow list-group-item px-1" onclick="javascript:parse_using_panda('${value.url}','${value.seendate}','${title}')" style="cursor: pointer;">
            <div class="row">
                <div class="col-3 text-primary fw-bold title">
                    <svg width="20" height="20" style="fill: currentColor;">
                        <use xlink:href="#link" />
                    </svg> ${value.domain}
                </div>
                <div class="col-8 text-muted fw-bold title">
                    ${value.title}
                </div>
                <div class="col-1 d-flex justify-content-end">${country}</div>
            </div>
            </li>
        `);
        });
        $("#article_list").html(top_stories_html);
    }
}


// Reddit Function
function subreddit_autocomplete() {
    $("#subreddit").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: "https://www.reddit.com/api/subreddit_autocomplete_v2.json?&raw_json=1&gilding_detail=1&nsfw=1",
                dataType: "json",
                data: {
                    query: request.term
                },
                success: function (data) {
                    response(
                        $.map(data.data.children, function (k, v) {
                            console.log(k, v);
                            return {
                                label: k.data.display_name,
                                value: k.data.display_name
                            };
                        })
                    );
                }
            });
        },
        minLength: 3,
        select: function (event, ui) {
            event.preventDefault();
            $("#subreddit").val(ui.item.label);
            var value = ui.item.label;
            var value = ui.item.value;
            $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
            get_response(`https://www.reddit.com/r/${value}/top/.json?sort=top&t=week&limit=100`).then((data) => { populate_reddit(data); });
            $(".main").attr("style", "");
            $(".content").animate({ scrollTop: 0 }, "fast");
        },
        focus: function (event, ui) {
            event.preventDefault();
            $("#subreddit").val(ui.item.label);
        }
    });
}
$('.r_worldnews_hour').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_reddit(GLOBALS.r_worldnews_hour);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
    var myOffcanvas = document.getElementById('offcanvasExample')
    var bsOffcanvas = new bootstrap.Offcanvas(myOffcanvas)
    bsOffcanvas.hide();
    // $("#offcanvasExample").Offcanvas('hide');
});
$('.r_worldnews_day').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_reddit(GLOBALS.r_worldnews_day);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
    // $("#offcanvasExample").Offcanvas('hide');
});
$('.r_worldnews_rising').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_reddit(GLOBALS.r_worldnews_rising);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
    // $("#offcanvasExample").Offcanvas('hide');

});
$('.r_all').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_reddit(GLOBALS.r_all);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
    // $("#offcanvasExample").Offcanvas('hide');

});
$('.rtrends').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_trending_reddit(GLOBALS.reddit_trends);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
    // $("#offcanvasExample").Offcanvas('hide');

});
function populate_reddit(data) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    if (typeof data.data.children !== 'undefined') {
        $.each(data.data.children, function (key, value) {
            var date = new Date(value.data.created * 1000);
            // let ye = new Intl.DateTimeFormat('en', { year: 'numeric' }).format(date);
            // let mo = new Intl.DateTimeFormat('en', { month: 'short' }).format(date);
            // let da = new Intl.DateTimeFormat('en', { day: '2-digit' }).format(date);
            // Hours part from the timestamp
            var hours = date.getHours();
            if (hours < 10) {
                hours = "0" + hours.toString();
            }
            // Minutes part from the timestamp
            var minutes = date.getMinutes();
            if (minutes < 10) {
                minutes = "0" + minutes.toString();
            }
            // Seconds part from the timestamp
            var seconds = date.getSeconds();
            if (seconds < 10) {
                seconds = "0" + seconds.toString();
            }
            title = value.data.title.replace(/(\r\n|\n|\r)/gm, "");
            title = title.replaceAll(/'/g, "");
            title = title.replaceAll(/"/g, "");
            title = title.replaceAll(/'/g, "\\'");
            top_stories_html = top_stories_html.concat(`
            <li class="tablerow list-group-item px-1" onclick="javascript:parse_reddit('${value.data.permalink}','${title}')" style="cursor: pointer;">
            <div class="row">
                <div class="col-3 text-primary fw-bold title">
                    <svg width="20" height="20" style="fill: currentColor;">
                        <use xlink:href="#link" />
                    </svg> ${value.data.domain}
                </div>
                <div class="col-8 text-muted fw-bold title">
                    ${title}
                </div>
                <div class="col-1 d-flex justify-content-end"></div>
            </div>
            </li>
        `);
        });
        $("#article_list").html(top_stories_html);
    }
}
function populate_trending_reddit(data) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    if (typeof data !== 'undefined') {
        $.each(data.trending_searches, function (key, value) {
            top_stories_html = top_stories_html.concat(`
            <li class="tablerow list-group-item px-1" onclick="javascript:parse_reddit('${value.results.data.children[0].data.permalink}','${value.results.data.children[0].data.title}')" style="cursor: pointer;">
            <div class="row">
                <div class="col-3 text-primary fw-bold title">
                    <svg width="20" height="20" style="fill: currentColor;">
                        <use xlink:href="#link" />
                    </svg> ${value.results.data.children[0].data.domain}
                </div>
                <div class="col-8 text-muted fw-bold title">
                    ${value.results.data.children[0].data.title}
                </div>
                <div class="col-1 d-flex justify-content-end"></div>
            </div>
            </li>
        `);
        });
        $("#article_list").html(top_stories_html);
    }
}
function parse_reddit(url, title) {
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    $(".tablerow").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    var { hostname } = new URL("https://www.reddit.com");
    url = `https://www.reddit.com/${url}.json`
    console.log(url);
    $.ajax({
        type: 'GET',
        url: url,
        success: function (data) {
            if (typeof data !== 'undefined') {
                $("#article_details").html(`<li class="list-group-item"><img src="https://www.google.com/s2/favicons?sz=24&domain=${hostname}" alt="" width="24" class="rounded-circle" />&nbsp;${title}</li>`);
                if (data[0].data.children[0].data.domain == "i.redd.it") {
                    if (data[0].data.children[0].data.url.includes("jpg") || data[0].data.children[0].data.url.includes("png") || data[0].data.children[0].data.url.includes("jpeg")) {
                        $("#article_details").append(`<li class="list-group-item"><img src="${data[0].data.children[0].data.url}" alt="Sry" style="max-height: 400px !important;max-width: 100% !important;object-fit: cover !important;" /></li>`)
                    }
                }
                else if (data[0].data.children[0].data.domain == "v.redd.it") {
                    console.log(data[0].data.children[0].data.secure_media.reddit_video.fallback_url);
                    vurl = data[0].data.children[0].data.secure_media.reddit_video.fallback_url;
                    vwidth = data[0].data.children[0].data.secure_media.reddit_video.width;
                    vheight = data[0].data.children[0].data.secure_media.reddit_video.height;
                    $("#article_details").append(`<li class="list-group-item">
                    <video width="${vwidth}" height="${vheight}" controls autoplay muted>
                    <source src="${vurl}" type="video/mp4">                    
                    Your browser does not support HTML video.
                    </video>
                    <br>
                    <img src="${data[0].data.children[0].data.thumbnail}" alt="Sry" style="max-height: 400px !important;max-width: 100% !important;object-fit: cover !important;" /></li>`);
                }
                else if (data[0].data.children[0].data.domain == "self.") {
                    $("#article_details").append(`<li class="list-group-item">${data[0].data.children[0].data.selftext_html}</li>`)
                }
                else if (data[0].data.children[0].data.domain == "i.imgur.com") {
                    $("#article_details").append(`<li class="list-group-item"><img src="${data[0].data.children[0].data.url}" alt="Sry" style="max-height: 400px !important;max-width: 100% !important;object-fit: cover !important;" /></li>`)
                }
                else {
                    parse_using_panda(data[0].data.children[0].data.url, "", title);
                }
                $.each(data[1].data.children, function (k, v) {
                    $("#article_details").append(`<li class="list-group-item"><strong>${v.data.author}</strong>:${htmlDecode(v.data.body_html)}</li>`)
                });

            } else {
                $("#article_details").append(`<li class="mt-1">We cannot parse this url. Please visit the source directly. <a href="https://www.reddit.com/${url}" target="_blank">Source</a></li>`);
                $("#article_details").append(`<hr>`);
            }
            $("#backbutton").attr("hidden", false);
            $("#article_details").attr("hidden", false);
            $("#article_list").attr("hidden", true);
            $(".main").attr("style", "");
            $(".tablerow").attr("style", "cursor: pointer;");
            $(".main").animate({ scrollTop: 0 }, "fast");
        },
        error: function (e) { console.log(e); }
    });
}


// Google Trends
$('.gtrends_india').on('click', function (e) {
    e.preventDefault();
    $("#article_list").html("");
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_gtrends(GLOBALS.google_trends);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});
function get_google_trends(geo) {
    return new Promise((resolve, reject) => {
        $.ajax({
            type: 'GET',
            url: `http://sbcors.herokuapp.com/https://trends.google.com/trends/api/dailytrends?hl=en-US&tz=-60&geo=${geo}&ns=15`,
            success: function (data) {
                reject(data);
            },
            error: function (e) {
                res = e.responseText.replace(")]}',", "");
                res = JSON.parse(res);
                resolve(res);
            }
        });
    })

}
function populate_gtrends(data) {
    $("#article_list").html("");
    $.each(data.default.trendingSearchesDays[0].trendingSearches, function (k, v) {
        var $listItem = $(`<li class="tablerow list-group-item px-1" style="cursor: pointer;">
        <div class="row">
            <div class="col-3 text-primary fw-bold">
                <svg width="20" height="20" style="fill: currentColor;">
                    <use xlink:href="#link" />
                </svg> ${v.title.query}
            </div>
            <div class="col-8 text-muted fw-bold title">
                ${v.title.query}
            </div>
            <div class="col-1 d-flex justify-content-end">${v.formattedTraffic}</div>
        </div>
    </li>`);
        // Find the button we just made and attach the click handler
        $listItem.click(function () {
            parse_gtrends(v);
        });
        $('#article_list').append($listItem);
    });
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
}
function parse_gtrends(v) {
    card_text = "";
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    $(".tablerow").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    console.log(v.articles);
    $.each(v.articles, function (i, j) {
        card_text = card_text.concat(`
        <div class="card mb-3" style="max-width: 540px;">
        <div class="row g-0">
          <div class="col-md-2">
            <img src="${j.image.imageUrl}" class="img-fluid rounded-start" alt="${j.image.source}">
          </div>
          <div class="col-md-10">
            <div class="card-body">
              <h5 class="card-title">${j.title}</h5>
              <p class="card-text">${j.snippet}</p>              
              <p class="card-text"><small class="text-muted">${j.timeAgo} | <a href="${j.url}" target="_blank">${j.source}</a></small></p>
            </div>
          </div>
        </div>
      </div>   
        `);
    });
    $("#article_details").html(card_text);
    $("#backbutton").attr("hidden", false);
    $("#article_details").attr("hidden", false);
    $("#article_list").attr("hidden", true);
    $(".main").attr("style", "");
    $(".tablerow").attr("style", "cursor: pointer;");
    $(".main").animate({ scrollTop: 0 }, "fast");
}

// Wiki 
// https://wikimedia.org/api/rest_v1/metrics/pageviews/top-per-country/IN/all-access/2021/08/30 - BY country
// https://wikimedia.org/api/rest_v1/metrics/pageviews/top/en.wikipedia/all-access/2021/09/10 - All English Wikipedia
// https://wikimedia.org/api/rest_v1/metrics/pageviews/top-by-country/all-projects/all-access/2021/08 - Which country acesses it most
$('.otd_holidays').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_otd(GLOBALS.otd, "holidays");
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});

$('.otd_birthdays').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_otd(GLOBALS.otd, "births");
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});

$('.otd_events').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_otd(GLOBALS.otd, "events");
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});

$('.otd_deaths').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_otd(GLOBALS.otd, "deaths");
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});
$('.otd_selected').on('click', function (e) {
    e.preventDefault();
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_otd(GLOBALS.otd, "selected");
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});
function populate_otd(data, type) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    if (typeof data !== 'undefined') {
        if (type == "holidays") {
            $.each(data.holidays, function (key, value) {
                extracted_html = `${value.pages[0].extract_html}`;
                if (!value.text.includes("Christian feast days")) {
                    top_stories_html = top_stories_html.concat(`    
                    <li class="tablerow list-group-item px-1" onclick="javascript:parse_wiki_page('${value.pages[0].titles.canonical}')" style="cursor: pointer;">
                    <div class="row">
                        <div class="col-3 text-primary fw-bold title">
                            <svg width="20" height="20" style="fill: currentColor;">
                                <use xlink:href="#link" />
                            </svg> ${value.pages[0].normalizedtitle}
                        </div>
                        <div class="col-8 text-muted fw-bold title">
                            ${value.text}
                        </div>
                        <div class="col-1 d-flex justify-content-end"></div>
                    </div>
                    </li> 
                    `);
                }

            });
            $("#article_list").html(top_stories_html);
        }
        else if (type == "births") {
            $.each(data.births, function (key, value) {
                top_stories_html = top_stories_html.concat(`    
                <li class="tablerow list-group-item px-1" onclick="javascript:parse_wiki_page('${value.pages[0].titles.canonical}')" style="cursor: pointer;">
                <div class="row">
                    <div class="col-3 text-primary fw-bold title">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${value.pages[0].normalizedtitle}
                    </div>
                    <div class="col-8 text-muted fw-bold title">
                        ${value.text}
                    </div>
                    <div class="col-1 d-flex justify-content-end">${value.year}</div>
                </div>
                </li> 
                `);
            });
            $("#article_list").html(top_stories_html);
        } 
        else if (type == "events") {
            $.each(data.events, function (key, value) {
                top_stories_html = top_stories_html.concat(`    
                <li class="tablerow list-group-item px-1" onclick="javascript:parse_wiki_page('${value.pages[0].titles.canonical}')" style="cursor: pointer;">
                <div class="row">
                    <div class="col-3 text-primary fw-bold title">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${value.pages[0].normalizedtitle}
                    </div>
                    <div class="col-8 text-muted fw-bold title">
                        ${value.text}
                    </div>
                    <div class="col-1 d-flex justify-content-end">${value.year}</div>
                </div>
                </li> 
                `);
            });
            $("#article_list").html(top_stories_html);
        }
        else if (type == "deaths") {
            $.each(data.deaths, function (key, value) {
                top_stories_html = top_stories_html.concat(`    
                <li class="tablerow list-group-item px-1" onclick="javascript:parse_wiki_page('${value.pages[0].titles.canonical}')" style="cursor: pointer;">
                <div class="row">
                    <div class="col-3 text-primary fw-bold title">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${value.pages[0].normalizedtitle}
                    </div>
                    <div class="col-8 text-muted fw-bold title">
                        ${value.text}
                    </div>
                    <div class="col-1 d-flex justify-content-end">${value.year}</div>
                </div>
                </li> 
                `);
            });
            $("#article_list").html(top_stories_html);
        } 
        else if(type == "selected") {
            $.each(data.selected, function (key, value) {
                top_stories_html = top_stories_html.concat(`    
                <li class="tablerow list-group-item px-1" onclick="javascript:wiki_extract('${value.pages[0].titles.canonical}')" style="cursor: pointer;">
                <div class="row">
                    <div class="col-3 text-primary fw-bold title">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${value.pages[0].normalizedtitle}
                    </div>
                    <div class="col-8 text-muted fw-bold title">
                        ${value.text}
                    </div>
                    <div class="col-1 d-flex justify-content-end">${value.year}</div>
                </div>
                </li> 
                `);
            });
            $("#article_list").html(top_stories_html);
        }
    }
}
function parse_wiki_page(title) {
    var url = "https://en.wikipedia.org/w/api.php";

    var params = {
        action: "parse",
        page: `${title}`,
        format: "json"
    };

    url = url + "?origin=*";
    Object.keys(params).forEach(function (key) { url += "&" + key + "=" + params[key]; });

    fetch(url)
        .then(function (response) { return response.json(); })
        .then(function (response) {
            $("#article_details").html(response.parse.text["*"]);
            $("#backbutton").attr("hidden", false);
            $("#article_details").attr("hidden", false);
            $("#article_list").attr("hidden", true);
            $(".main").attr("style", "");
            $(".tablerow").attr("style", "cursor: pointer;");
            $(".main").animate({ scrollTop: 0 }, "fast");
            // console.log(response.parse.text["*"]);
        })
        .catch(function (error) { console.log(error); });
}
function wiki_extract(title) {
    $.ajax({
        type: 'GET',
        url: "https://en.wikipedia.org/api/rest_v1/page/mobile-sections-lead/" + title,
        success: function (data) {
            if (typeof data !== 'undefined') {
                // $("#article_text").html(`<strong class="text-info"">TL;DR</strong><br>${extract}<hr>`);
                $("#article_details").html(data.sections[0].text);
                $("#backbutton").attr("hidden", false);
                $("#article_details").attr("hidden", false);
                $("#article_list").attr("hidden", true);
                $(".main").attr("style", "");
                $(".tablerow").attr("style", "cursor: pointer;");
                $(".main").animate({ scrollTop: 0 }, "fast");
            }
        },
        error: function (e) { console.log(e); }
    });

}
$('.wtrends_india').on('click', function (e) {
    e.preventDefault();
    $("#article_list").html("");
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_wiki_trends(GLOBALS.wiki_trends);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});
function populate_wiki_trends(data) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    if (typeof data !== 'undefined') {
        $.each(data.items[0].articles, function (key, value) {
            if(value.project=="en.wikipedia"){
                top_stories_html = top_stories_html.concat(`    
                <li class="tablerow list-group-item px-1" onclick="javascript:parse_wiki_page('${value.article}')" style="cursor: pointer;">
                <div class="row">
                    <div class="col-3 text-primary fw-bold title">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${value.article}
                    </div>
                    <div class="col-8 text-muted fw-bold title">
                     Number of views: ${value.views_ceil}
                    </div>
                    <div class="col-1 d-flex justify-content-end">${value.rank}</div>
                </div>
                </li> 
                `);
            }
           
        });
        $("#article_list").html(top_stories_html);

    }
}
function get_wiki_trends(geo) {
    const d = new Date();
    year = d.getFullYear();
    month = d.getMonth() + 1;
    day = d.getDate() - 1;
    if (month < 10) { month = "0" + month }
    if (day < 10) { day = "0" + day }
    return new Promise((resolve, reject) => {
        $.ajax({
            type: 'GET',
            headers: { 'Api-User-Agent': 'duumbeeee@gmail.com' },
            url: `https://wikimedia.org/api/rest_v1/metrics/pageviews/top-per-country/${geo}/all-access/${year}/${month}/${day}`,
            success: function (data) {
                resolve(data);
            },
            error: function (e) {
                reject(e);
            }
        });
    })
}
function get_geo_wiki() {
    var url = "https://en.wikipedia.org/w/api.php";

    var params = {
        action: "query",
        format: "json",
        titles: "Narendra Modi",
        prop: "links"
    };

    url = url + "?origin=*";
    Object.keys(params).forEach(function (key) { url += "&" + key + "=" + params[key]; });

    fetch(url)
        .then(function (response) { return response.json(); })
        .then(function (response) {
            // console.log(response.query.pages);
            var pages = response.query.pages;
            for (var p in pages) {
                for (var l of pages[p].links) {
                    console.log(l.title);
                }
            }
        })
        .catch(function (error) { console.log(error); });
}

$('.ttrends_india').on('click', function (e) {
    e.preventDefault();
    $("#article_list").html("");
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_twitter(GLOBALS.twitter_trends);
    $(".main").attr("style", "");
    $(".content").animate({ scrollTop: 0 }, "fast");
});
// Twitter Trends
function populate_twitter(data) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    if (typeof data !== 'undefined') {
        $.each(data, function (key, value) {
            var t_v = '';
            if(!value.tweet_volume){
                t_v = "Less than 10K"
            }else{
                t_v = new Intl.NumberFormat('en-GB', { maximumSignificantDigits: 3 }).format(value.tweet_volume) + " tweets"
            }
            top_stories_html = top_stories_html.concat(`
            <li class="tablerow list-group-item px-1" style="cursor: pointer;">
            <div class="row">
                <div class="col-3 text-primary fw-bold title">
                    <svg width="20" height="20" style="fill: currentColor;">
                        <use xlink:href="#link" />
                    </svg> ${value.name}
                </div>
                <div class="col-8 text-muted fw-bold title">
                    ${t_v}
                </div>
                <div class="col-1 d-flex justify-content-end"></div>
            </div>
            </li>
        `);
        });
        $("#article_list").html(top_stories_html);
    }
}