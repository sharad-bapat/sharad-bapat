GLOBALS = {};

function setLocalStorage(key, value, ttl) {
    const now = new Date();
    const item = {
        value: value,
        expiry: now.getTime() + ttl
    };
    localStorage.setItem(key, JSON.stringify(item));
}
function getLocalStorage(key) {
    const itemStr = localStorage.getItem(key);
    if (!itemStr) {
        return null;
    }
    const item = JSON.parse(itemStr);
    const now = new Date();
    if (now.getTime() > item.expiry) {
        localStorage.removeItem(key);
        return null;
    }
    return item.value;
}
Storage.prototype.deleteLocalStorage = function (key) {
    this.removeItem(key);
}
function get_localstorage_size() {
    var _lsTotal = 0,
        _xLen, _x;
    for (_x in localStorage) {
        if (!localStorage.hasOwnProperty(_x)) {
            continue;
        }
        _xLen = ((localStorage[_x].length + _x.length) * 2);
        _lsTotal += _xLen;
        console.log(_x.substr(0, 50) + " = " + (_xLen / 1024).toFixed(2) + " KB")
    };
    console.log("Total = " + (_lsTotal / 1024).toFixed(2) + " KB");
}
function get_response(url) {
    return new Promise((resolve, reject) => {
        $.ajax({
            type: 'GET',
            url: url,
            success: function (data) {
                resolve(data);
            },
            error: function (e) { reject(e); }
        });
    })
}
$(function () {
    get_localstorage_size();
    if (!getLocalStorage("emm_top")) {
        console.log("Fetching EMM Top from server");
        get_response("https://emm.newsbrief.eu/emmMap/tunnel?sid=emmMap&?stories=top&language=en").then((data) => { setLocalStorage("emm_top", data, 15 * 60000); GLOBALS.emm_top = data; populate_emm(data) });
    } else {
        console.log("Fetching EMM Top from local storage");
        GLOBALS.emm_top = getLocalStorage("emm_top");
        populate_emm(GLOBALS.emm_top);
    }    
    if (!getLocalStorage("emm_events")) {
        console.log("Fetching EMM Events from server");
        get_response("https://emm.newsbrief.eu/emmMap/tunnel?sid=emmMap&?stories=events&language=en").then((data) => { setLocalStorage("emm_events", data, 30 * 60000); GLOBALS.emm_events = data;});
    } else {
        console.log("Fetching EMM Events from local storage");
        GLOBALS.emm_events = getLocalStorage("emm_events");         
    }
    if (!getLocalStorage("emm_india")) {
        console.log("Fetching EMM India from server");
        get_response("https://emm.newsbrief.eu/emmMap/tunnel?sid=emmMap-1&?category=India&rows=100&language=en").then((data) => { setLocalStorage("emm_india", data, 30 * 60000); GLOBALS.emm_india = data;});
    } else {
        console.log("Fetching EMM India from local storage");
        GLOBALS.emm_india = getLocalStorage("emm_india");         
    }
});


$('#a_emm_top').on('click', function (e) {
    e.preventDefault();    
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_emm(GLOBALS.emm_top);
    $(".main").attr("style", "");
});
$('#a_emm_events').on('click', function (e) {
    e.preventDefault();   
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_emm(GLOBALS.emm_events);
    $(".main").attr("style", "");
});
$('#a_emm_india').on('click', function (e) {
    e.preventDefault();   
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    populate_emm_map(GLOBALS.emm_india);
    $(".main").attr("style", "");
});
function populate_emm(data) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    if (typeof data.items !== 'undefined') {
        $.each(data.items, function (key, value) {
            // 2021-08-30T22:26+0200
            // 2021 7 -3 T2
            // `<details class="mb-1"><summary>${value.title}</summary><p class="p-1">${value.description}</span> | ${da}-${mo}-${ye}</p>`,
            var d = new Date(value.pubDate.substr(0, 4), value.pubDate.substr(5, 2) - 1, value.pubDate.substr(8, 2));
            let ye = new Intl.DateTimeFormat('en', { year: 'numeric' }).format(d);
            let mo = new Intl.DateTimeFormat('en', { month: '2-digit' }).format(d);
            let da = new Intl.DateTimeFormat('en', { day: '2-digit' }).format(d);
            title = value.title.replace(/(\r\n|\n|\r)/gm, "");
            title = title.replaceAll(/'/g, "");
            title = title.replaceAll(/"/g, "");
            title = title.replaceAll(/'/g, "\\'");
            top_stories_html = top_stories_html.concat(`
                <li class="tablerow list-group-item px-1" onclick="javascript:parse_using_panda('${value.mainItemLink}','${value.pubDate}','${title}')" style="cursor: pointer;">
                <div class="row">
                    <div class="col-3 text-primary fw-bold">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${value.mainItemSource.value}
                    </div>
                    <div class="col-8 text-muted fw-bold">
                        ${value.title}
                    </div>
                    <div class="col-1 d-flex justify-content-end">${value.mainItemSource.country}</div>
                </div>
                </li>
            `);
        });
        $("#article_list").html(top_stories_html);
    }
}
function populate_emm_map(data) {
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    top_stories_html = "";
    if (typeof data.itemMap !== 'undefined') {
        $.each(data.itemMap, function (key, value) {
            // 2021-08-30T22:26+0200
            // 2021 7 -3 T2
            // `<details class="mb-1"><summary>${value.title}</summary><p class="p-1">${value.description}</span> | ${da}-${mo}-${ye}</p>`,
            var d = new Date(value.pubDate.substr(0, 4), value.pubDate.substr(5, 2) - 1, value.pubDate.substr(8, 2));
            let ye = new Intl.DateTimeFormat('en', { year: 'numeric' }).format(d);
            let mo = new Intl.DateTimeFormat('en', { month: '2-digit' }).format(d);
            let da = new Intl.DateTimeFormat('en', { day: '2-digit' }).format(d);
            title = value.title.replace(/(\r\n|\n|\r)/gm, "");
            title = title.replaceAll(/'/g, "");
            title = title.replaceAll(/"/g, "");
            title = title.replaceAll(/'/g, "\\'");
            top_stories_html = top_stories_html.concat(`
                <li class="tablerow list-group-item px-1" onclick="javascript:parse_using_panda('${value.link}','${value.pubDate}','${title}')" style="cursor: pointer;">
                <div class="row">
                    <div class="col-3 text-primary fw-bold">
                        <svg width="20" height="20" style="fill: currentColor;">
                            <use xlink:href="#link" />
                        </svg> ${value.source.value}
                    </div>
                    <div class="col-8 text-muted fw-bold">
                        ${value.title}
                    </div>
                    <div class="col-1 d-flex justify-content-end">${value.source.country}</div>
                </div>
                </li>
            `);
        });
        $("#article_list").html(top_stories_html);
    }
}

function parse_using_panda(url, pubdate, title) {
    $(".main").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    $(".tablerow").attr("style", "background-color: #eee;opacity: 1.0;cursor: wait;");
    var { hostname } = new URL(url);
    $.ajax({
        type: 'GET',
        url: `https://api-panda.com/v2/feeds/story/full?url=${url}`,
        success: function (data) {
            if (typeof data.data !== 'undefined') {
                $("#article_details").html(`<li class="list-group-item"><img src="https://www.google.com/s2/favicons?sz=24&domain=${hostname}" alt="" width="24" class="rounded-circle" />&nbsp;${title} <span class="small text-muted">${pubdate}</span</li>`);                               
                $("#article_details").append(`<li class="list-group-item">${data.data.html}</li>`)
            } else {
                $(".article_details").append(`<li class="mt-1">We cannot parse this url. Please visit the source directly. <a href="${url}" target="_blank">Source</a></li>`);
                $(".article_details").append(`<hr>`);
            }
            $("#backbutton").attr("hidden", false);
            $("#article_details").attr("hidden", false);
            $("#article_list").attr("hidden", true);
            $(".main").attr("style", "");
            $(".tablerow").attr("style", "");
        },
        error: function (e) { console.log(e); }
    });
}   
function toogle_list(){
    $("#backbutton").attr("hidden", true);
    $("#article_details").attr("hidden", true);
    $("#article_list").attr("hidden", false);
    $(".main").attr("style", "");
    $(".tablerow").attr("style", "");
}

