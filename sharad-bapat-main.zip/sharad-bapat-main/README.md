- 👋 Hi, I’m @sharad-bapat
- 👀 I’m interested in Open Source, Python, JavaScript, AI, ML
- 🌱 I’m always learning
- 💞️ I’m looking to collaborate on exciting open source project and contribute meaningfully.
- 📫 Follow me on twitter - > https://twitter.com/sharad_bapat 

<!---
sharad-bapat/sharad-bapat is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
